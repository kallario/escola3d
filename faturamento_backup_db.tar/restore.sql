--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.19
-- Dumped by pg_dump version 9.5.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.evento_contratos DROP CONSTRAINT fk_rails_f49398363f;
ALTER TABLE ONLY public.eventos DROP CONSTRAINT fk_rails_f2b9d888e2;
ALTER TABLE ONLY public.ticket_movimentos DROP CONSTRAINT fk_rails_dba027c891;
ALTER TABLE ONLY public.faturas DROP CONSTRAINT fk_rails_a36a1e5090;
ALTER TABLE ONLY public.eventos DROP CONSTRAINT fk_rails_94e3092784;
ALTER TABLE ONLY public.pessoas DROP CONSTRAINT fk_rails_81b663bea4;
ALTER TABLE ONLY public.clientes DROP CONSTRAINT fk_rails_7b6aa07c78;
ALTER TABLE ONLY public.clientes DROP CONSTRAINT fk_rails_7819d066a4;
ALTER TABLE ONLY public.contratos DROP CONSTRAINT fk_rails_7118cf7082;
ALTER TABLE ONLY public.fatura_itens DROP CONSTRAINT fk_rails_6339760cdb;
ALTER TABLE ONLY public.produtos DROP CONSTRAINT fk_rails_590c9073f0;
ALTER TABLE ONLY public.item_contratos DROP CONSTRAINT fk_rails_5720d03496;
ALTER TABLE ONLY public.contratos DROP CONSTRAINT fk_rails_4b12b84b0d;
ALTER TABLE ONLY public.fatura_itens DROP CONSTRAINT fk_rails_41b699d639;
ALTER TABLE ONLY public.evento_contratos DROP CONSTRAINT fk_rails_36203af0ac;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT fk_rails_2c0070d11e;
ALTER TABLE ONLY public.ticket_movimentos DROP CONSTRAINT fk_rails_29a7c42f1c;
ALTER TABLE ONLY public.fatura_itens DROP CONSTRAINT fk_rails_20838c8bc1;
ALTER TABLE ONLY public.item_contratos DROP CONSTRAINT fk_rails_14ff4bcf84;
ALTER TABLE ONLY public.eventos DROP CONSTRAINT fk_rails_1345469dfd;
ALTER TABLE ONLY minhascontas.evento_contratos DROP CONSTRAINT fk_rails_f49398363f;
ALTER TABLE ONLY minhascontas.eventos DROP CONSTRAINT fk_rails_f2b9d888e2;
ALTER TABLE ONLY minhascontas.ticket_movimentos DROP CONSTRAINT fk_rails_dba027c891;
ALTER TABLE ONLY minhascontas.faturas DROP CONSTRAINT fk_rails_a36a1e5090;
ALTER TABLE ONLY minhascontas.eventos DROP CONSTRAINT fk_rails_94e3092784;
ALTER TABLE ONLY minhascontas.pessoas DROP CONSTRAINT fk_rails_81b663bea4;
ALTER TABLE ONLY minhascontas.clientes DROP CONSTRAINT fk_rails_7b6aa07c78;
ALTER TABLE ONLY minhascontas.clientes DROP CONSTRAINT fk_rails_7819d066a4;
ALTER TABLE ONLY minhascontas.contratos DROP CONSTRAINT fk_rails_7118cf7082;
ALTER TABLE ONLY minhascontas.fatura_itens DROP CONSTRAINT fk_rails_6339760cdb;
ALTER TABLE ONLY minhascontas.produtos DROP CONSTRAINT fk_rails_590c9073f0;
ALTER TABLE ONLY minhascontas.item_contratos DROP CONSTRAINT fk_rails_5720d03496;
ALTER TABLE ONLY minhascontas.contratos DROP CONSTRAINT fk_rails_4b12b84b0d;
ALTER TABLE ONLY minhascontas.fatura_itens DROP CONSTRAINT fk_rails_41b699d639;
ALTER TABLE ONLY minhascontas.evento_contratos DROP CONSTRAINT fk_rails_36203af0ac;
ALTER TABLE ONLY minhascontas.tickets DROP CONSTRAINT fk_rails_2c0070d11e;
ALTER TABLE ONLY minhascontas.ticket_movimentos DROP CONSTRAINT fk_rails_29a7c42f1c;
ALTER TABLE ONLY minhascontas.fatura_itens DROP CONSTRAINT fk_rails_20838c8bc1;
ALTER TABLE ONLY minhascontas.item_contratos DROP CONSTRAINT fk_rails_14ff4bcf84;
ALTER TABLE ONLY minhascontas.eventos DROP CONSTRAINT fk_rails_1345469dfd;
ALTER TABLE ONLY kallario.eventos DROP CONSTRAINT fk_rails_f2b9d888e2;
ALTER TABLE ONLY kallario.contratos DROP CONSTRAINT fk_rails_c7d03eb372;
ALTER TABLE ONLY kallario.faturas DROP CONSTRAINT fk_rails_a36a1e5090;
ALTER TABLE ONLY kallario.eventos DROP CONSTRAINT fk_rails_1345469dfd;
ALTER TABLE ONLY financeiro.evento_contratos DROP CONSTRAINT fk_rails_f49398363f;
ALTER TABLE ONLY financeiro.eventos DROP CONSTRAINT fk_rails_f2b9d888e2;
ALTER TABLE ONLY financeiro.ticket_movimentos DROP CONSTRAINT fk_rails_dba027c891;
ALTER TABLE ONLY financeiro.faturas DROP CONSTRAINT fk_rails_a36a1e5090;
ALTER TABLE ONLY financeiro.eventos DROP CONSTRAINT fk_rails_94e3092784;
ALTER TABLE ONLY financeiro.pessoas DROP CONSTRAINT fk_rails_81b663bea4;
ALTER TABLE ONLY financeiro.clientes DROP CONSTRAINT fk_rails_7b6aa07c78;
ALTER TABLE ONLY financeiro.clientes DROP CONSTRAINT fk_rails_7819d066a4;
ALTER TABLE ONLY financeiro.contratos DROP CONSTRAINT fk_rails_7118cf7082;
ALTER TABLE ONLY financeiro.fatura_itens DROP CONSTRAINT fk_rails_6339760cdb;
ALTER TABLE ONLY financeiro.produtos DROP CONSTRAINT fk_rails_590c9073f0;
ALTER TABLE ONLY financeiro.item_contratos DROP CONSTRAINT fk_rails_5720d03496;
ALTER TABLE ONLY financeiro.contratos DROP CONSTRAINT fk_rails_4b12b84b0d;
ALTER TABLE ONLY financeiro.fatura_itens DROP CONSTRAINT fk_rails_41b699d639;
ALTER TABLE ONLY financeiro.evento_contratos DROP CONSTRAINT fk_rails_36203af0ac;
ALTER TABLE ONLY financeiro.tickets DROP CONSTRAINT fk_rails_2c0070d11e;
ALTER TABLE ONLY financeiro.ticket_movimentos DROP CONSTRAINT fk_rails_29a7c42f1c;
ALTER TABLE ONLY financeiro.fatura_itens DROP CONSTRAINT fk_rails_20838c8bc1;
ALTER TABLE ONLY financeiro.item_contratos DROP CONSTRAINT fk_rails_14ff4bcf84;
ALTER TABLE ONLY financeiro.eventos DROP CONSTRAINT fk_rails_1345469dfd;
ALTER TABLE ONLY faturamento.evento_contratos DROP CONSTRAINT fk_rails_f49398363f;
ALTER TABLE ONLY faturamento.eventos DROP CONSTRAINT fk_rails_f2b9d888e2;
ALTER TABLE ONLY faturamento.ticket_movimentos DROP CONSTRAINT fk_rails_dba027c891;
ALTER TABLE ONLY faturamento.faturas DROP CONSTRAINT fk_rails_a36a1e5090;
ALTER TABLE ONLY faturamento.eventos DROP CONSTRAINT fk_rails_94e3092784;
ALTER TABLE ONLY faturamento.pessoas DROP CONSTRAINT fk_rails_81b663bea4;
ALTER TABLE ONLY faturamento.clientes DROP CONSTRAINT fk_rails_7819d066a4;
ALTER TABLE ONLY faturamento.contratos DROP CONSTRAINT fk_rails_7118cf7082;
ALTER TABLE ONLY faturamento.fatura_itens DROP CONSTRAINT fk_rails_6339760cdb;
ALTER TABLE ONLY faturamento.produtos DROP CONSTRAINT fk_rails_590c9073f0;
ALTER TABLE ONLY faturamento.item_contratos DROP CONSTRAINT fk_rails_5720d03496;
ALTER TABLE ONLY faturamento.contratos DROP CONSTRAINT fk_rails_4b12b84b0d;
ALTER TABLE ONLY faturamento.fatura_itens DROP CONSTRAINT fk_rails_41b699d639;
ALTER TABLE ONLY faturamento.evento_contratos DROP CONSTRAINT fk_rails_36203af0ac;
ALTER TABLE ONLY faturamento.tickets DROP CONSTRAINT fk_rails_2c0070d11e;
ALTER TABLE ONLY faturamento.ticket_movimentos DROP CONSTRAINT fk_rails_29a7c42f1c;
ALTER TABLE ONLY faturamento.fatura_itens DROP CONSTRAINT fk_rails_20838c8bc1;
ALTER TABLE ONLY faturamento.item_contratos DROP CONSTRAINT fk_rails_14ff4bcf84;
ALTER TABLE ONLY faturamento.eventos DROP CONSTRAINT fk_rails_1345469dfd;
DROP INDEX public.index_tickets_on_cliente_id;
DROP INDEX public.index_ticket_movimentos_on_ticket_id;
DROP INDEX public.index_ticket_movimentos_on_pessoa_id;
DROP INDEX public.index_produtos_on_grupo_id;
DROP INDEX public.index_pessoas_on_reset_password_token;
DROP INDEX public.index_pessoas_on_email;
DROP INDEX public.index_pessoas_on_contador_id;
DROP INDEX public.index_item_contratos_on_produto_id;
DROP INDEX public.index_item_contratos_on_contrato_id;
DROP INDEX public.index_faturas_on_contrato_id;
DROP INDEX public.index_fatura_itens_on_produto_id;
DROP INDEX public.index_fatura_itens_on_pessoa_id;
DROP INDEX public.index_fatura_itens_on_fatura_id;
DROP INDEX public.index_eventos_on_pessoa_id;
DROP INDEX public.index_eventos_on_forma_pagamento_id;
DROP INDEX public.index_eventos_on_fatura_id;
DROP INDEX public.index_evento_contratos_on_pessoa_id;
DROP INDEX public.index_evento_contratos_on_contrato_id;
DROP INDEX public.index_contratos_on_forma_pagamento_id;
DROP INDEX public.index_contratos_on_cliente_id;
DROP INDEX public.index_clientes_on_pessoa_id;
DROP INDEX public.index_clientes_on_contador_id;
DROP INDEX minhascontas.index_tickets_on_cliente_id;
DROP INDEX minhascontas.index_ticket_movimentos_on_ticket_id;
DROP INDEX minhascontas.index_ticket_movimentos_on_pessoa_id;
DROP INDEX minhascontas.index_produtos_on_grupo_id;
DROP INDEX minhascontas.index_pessoas_on_reset_password_token;
DROP INDEX minhascontas.index_pessoas_on_email;
DROP INDEX minhascontas.index_pessoas_on_contador_id;
DROP INDEX minhascontas.index_item_contratos_on_produto_id;
DROP INDEX minhascontas.index_item_contratos_on_contrato_id;
DROP INDEX minhascontas.index_faturas_on_contrato_id;
DROP INDEX minhascontas.index_fatura_itens_on_produto_id;
DROP INDEX minhascontas.index_fatura_itens_on_pessoa_id;
DROP INDEX minhascontas.index_fatura_itens_on_fatura_id;
DROP INDEX minhascontas.index_eventos_on_pessoa_id;
DROP INDEX minhascontas.index_eventos_on_forma_pagamento_id;
DROP INDEX minhascontas.index_eventos_on_fatura_id;
DROP INDEX minhascontas.index_evento_contratos_on_pessoa_id;
DROP INDEX minhascontas.index_evento_contratos_on_contrato_id;
DROP INDEX minhascontas.index_contratos_on_forma_pagamento_id;
DROP INDEX minhascontas.index_contratos_on_cliente_id;
DROP INDEX minhascontas.index_clientes_on_pessoa_id;
DROP INDEX minhascontas.index_clientes_on_contador_id;
DROP INDEX kallario.index_pessoas_on_reset_password_token;
DROP INDEX kallario.index_pessoas_on_email;
DROP INDEX kallario.index_faturas_on_contrato_id;
DROP INDEX kallario.index_eventos_on_pessoa_id;
DROP INDEX kallario.index_eventos_on_fatura_id;
DROP INDEX kallario.index_contratos_on_pessoa_id;
DROP INDEX financeiro.index_tickets_on_cliente_id;
DROP INDEX financeiro.index_ticket_movimentos_on_ticket_id;
DROP INDEX financeiro.index_ticket_movimentos_on_pessoa_id;
DROP INDEX financeiro.index_produtos_on_grupo_id;
DROP INDEX financeiro.index_pessoas_on_reset_password_token;
DROP INDEX financeiro.index_pessoas_on_email;
DROP INDEX financeiro.index_pessoas_on_contador_id;
DROP INDEX financeiro.index_item_contratos_on_produto_id;
DROP INDEX financeiro.index_item_contratos_on_contrato_id;
DROP INDEX financeiro.index_faturas_on_contrato_id;
DROP INDEX financeiro.index_fatura_itens_on_produto_id;
DROP INDEX financeiro.index_fatura_itens_on_pessoa_id;
DROP INDEX financeiro.index_fatura_itens_on_fatura_id;
DROP INDEX financeiro.index_eventos_on_pessoa_id;
DROP INDEX financeiro.index_eventos_on_forma_pagamento_id;
DROP INDEX financeiro.index_eventos_on_fatura_id;
DROP INDEX financeiro.index_evento_contratos_on_pessoa_id;
DROP INDEX financeiro.index_evento_contratos_on_contrato_id;
DROP INDEX financeiro.index_contratos_on_forma_pagamento_id;
DROP INDEX financeiro.index_contratos_on_cliente_id;
DROP INDEX financeiro.index_clientes_on_pessoa_id;
DROP INDEX financeiro.index_clientes_on_contador_id;
DROP INDEX faturamento.index_tickets_on_cliente_id;
DROP INDEX faturamento.index_ticket_movimentos_on_ticket_id;
DROP INDEX faturamento.index_ticket_movimentos_on_pessoa_id;
DROP INDEX faturamento.index_produtos_on_grupo_id;
DROP INDEX faturamento.index_pessoas_on_reset_password_token;
DROP INDEX faturamento.index_pessoas_on_email;
DROP INDEX faturamento.index_pessoas_on_contador_id;
DROP INDEX faturamento.index_item_contratos_on_produto_id;
DROP INDEX faturamento.index_item_contratos_on_contrato_id;
DROP INDEX faturamento.index_faturas_on_contrato_id;
DROP INDEX faturamento.index_fatura_itens_on_produto_id;
DROP INDEX faturamento.index_fatura_itens_on_pessoa_id;
DROP INDEX faturamento.index_fatura_itens_on_fatura_id;
DROP INDEX faturamento.index_eventos_on_pessoa_id;
DROP INDEX faturamento.index_eventos_on_forma_pagamento_id;
DROP INDEX faturamento.index_eventos_on_fatura_id;
DROP INDEX faturamento.index_evento_contratos_on_pessoa_id;
DROP INDEX faturamento.index_evento_contratos_on_contrato_id;
DROP INDEX faturamento.index_contratos_on_forma_pagamento_id;
DROP INDEX faturamento.index_contratos_on_cliente_id;
DROP INDEX faturamento.index_clientes_on_contador_id;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY public.ticket_movimentos DROP CONSTRAINT ticket_movimentos_pkey;
ALTER TABLE ONLY public.ticket_configs DROP CONSTRAINT ticket_configs_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.produtos DROP CONSTRAINT produtos_pkey;
ALTER TABLE ONLY public.pessoas DROP CONSTRAINT pessoas_pkey;
ALTER TABLE ONLY public.notificacoes DROP CONSTRAINT notificacoes_pkey;
ALTER TABLE ONLY public.item_contratos DROP CONSTRAINT item_contratos_pkey;
ALTER TABLE ONLY public.grupos DROP CONSTRAINT grupos_pkey;
ALTER TABLE ONLY public.forma_pagamentos DROP CONSTRAINT forma_pagamentos_pkey;
ALTER TABLE ONLY public.faturas DROP CONSTRAINT faturas_pkey;
ALTER TABLE ONLY public.fatura_itens DROP CONSTRAINT fatura_itens_pkey;
ALTER TABLE ONLY public.eventos DROP CONSTRAINT eventos_pkey;
ALTER TABLE ONLY public.evento_contratos DROP CONSTRAINT evento_contratos_pkey;
ALTER TABLE ONLY public.empresas DROP CONSTRAINT empresas_pkey;
ALTER TABLE ONLY public.contratos DROP CONSTRAINT contratos_pkey;
ALTER TABLE ONLY public.contadores DROP CONSTRAINT contadores_pkey;
ALTER TABLE ONLY public.clientes DROP CONSTRAINT clientes_pkey;
ALTER TABLE ONLY public.chaves DROP CONSTRAINT chaves_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY public.ajudas DROP CONSTRAINT ajudas_pkey;
ALTER TABLE ONLY minhascontas.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY minhascontas.ticket_movimentos DROP CONSTRAINT ticket_movimentos_pkey;
ALTER TABLE ONLY minhascontas.ticket_configs DROP CONSTRAINT ticket_configs_pkey;
ALTER TABLE ONLY minhascontas.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY minhascontas.produtos DROP CONSTRAINT produtos_pkey;
ALTER TABLE ONLY minhascontas.pessoas DROP CONSTRAINT pessoas_pkey;
ALTER TABLE ONLY minhascontas.notificacoes DROP CONSTRAINT notificacoes_pkey;
ALTER TABLE ONLY minhascontas.item_contratos DROP CONSTRAINT item_contratos_pkey;
ALTER TABLE ONLY minhascontas.grupos DROP CONSTRAINT grupos_pkey;
ALTER TABLE ONLY minhascontas.forma_pagamentos DROP CONSTRAINT forma_pagamentos_pkey;
ALTER TABLE ONLY minhascontas.faturas DROP CONSTRAINT faturas_pkey;
ALTER TABLE ONLY minhascontas.fatura_itens DROP CONSTRAINT fatura_itens_pkey;
ALTER TABLE ONLY minhascontas.eventos DROP CONSTRAINT eventos_pkey;
ALTER TABLE ONLY minhascontas.evento_contratos DROP CONSTRAINT evento_contratos_pkey;
ALTER TABLE ONLY minhascontas.empresas DROP CONSTRAINT empresas_pkey;
ALTER TABLE ONLY minhascontas.contratos DROP CONSTRAINT contratos_pkey;
ALTER TABLE ONLY minhascontas.contadores DROP CONSTRAINT contadores_pkey;
ALTER TABLE ONLY minhascontas.clientes DROP CONSTRAINT clientes_pkey;
ALTER TABLE ONLY minhascontas.chaves DROP CONSTRAINT chaves_pkey;
ALTER TABLE ONLY minhascontas.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY minhascontas.ajudas DROP CONSTRAINT ajudas_pkey;
ALTER TABLE ONLY kallario.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY kallario.pessoas DROP CONSTRAINT pessoas_pkey;
ALTER TABLE ONLY kallario.faturas DROP CONSTRAINT faturas_pkey;
ALTER TABLE ONLY kallario.eventos DROP CONSTRAINT eventos_pkey;
ALTER TABLE ONLY kallario.empresas DROP CONSTRAINT empresas_pkey;
ALTER TABLE ONLY kallario.contratos DROP CONSTRAINT contratos_pkey;
ALTER TABLE ONLY kallario.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY financeiro.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY financeiro.ticket_movimentos DROP CONSTRAINT ticket_movimentos_pkey;
ALTER TABLE ONLY financeiro.ticket_configs DROP CONSTRAINT ticket_configs_pkey;
ALTER TABLE ONLY financeiro.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY financeiro.produtos DROP CONSTRAINT produtos_pkey;
ALTER TABLE ONLY financeiro.pessoas DROP CONSTRAINT pessoas_pkey;
ALTER TABLE ONLY financeiro.notificacoes DROP CONSTRAINT notificacoes_pkey;
ALTER TABLE ONLY financeiro.item_contratos DROP CONSTRAINT item_contratos_pkey;
ALTER TABLE ONLY financeiro.grupos DROP CONSTRAINT grupos_pkey;
ALTER TABLE ONLY financeiro.forma_pagamentos DROP CONSTRAINT forma_pagamentos_pkey;
ALTER TABLE ONLY financeiro.faturas DROP CONSTRAINT faturas_pkey;
ALTER TABLE ONLY financeiro.fatura_itens DROP CONSTRAINT fatura_itens_pkey;
ALTER TABLE ONLY financeiro.eventos DROP CONSTRAINT eventos_pkey;
ALTER TABLE ONLY financeiro.evento_contratos DROP CONSTRAINT evento_contratos_pkey;
ALTER TABLE ONLY financeiro.empresas DROP CONSTRAINT empresas_pkey;
ALTER TABLE ONLY financeiro.contratos DROP CONSTRAINT contratos_pkey;
ALTER TABLE ONLY financeiro.contadores DROP CONSTRAINT contadores_pkey;
ALTER TABLE ONLY financeiro.clientes DROP CONSTRAINT clientes_pkey;
ALTER TABLE ONLY financeiro.chaves DROP CONSTRAINT chaves_pkey;
ALTER TABLE ONLY financeiro.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY financeiro.ajudas DROP CONSTRAINT ajudas_pkey;
ALTER TABLE ONLY faturamento.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY faturamento.ticket_movimentos DROP CONSTRAINT ticket_movimentos_pkey;
ALTER TABLE ONLY faturamento.ticket_configs DROP CONSTRAINT ticket_configs_pkey;
ALTER TABLE ONLY faturamento.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY faturamento.produtos DROP CONSTRAINT produtos_pkey;
ALTER TABLE ONLY faturamento.pessoas DROP CONSTRAINT pessoas_pkey;
ALTER TABLE ONLY faturamento.notificacoes DROP CONSTRAINT notificacoes_pkey;
ALTER TABLE ONLY faturamento.item_contratos DROP CONSTRAINT item_contratos_pkey;
ALTER TABLE ONLY faturamento.grupos DROP CONSTRAINT grupos_pkey;
ALTER TABLE ONLY faturamento.forma_pagamentos DROP CONSTRAINT forma_pagamentos_pkey;
ALTER TABLE ONLY faturamento.faturas DROP CONSTRAINT faturas_pkey;
ALTER TABLE ONLY faturamento.fatura_itens DROP CONSTRAINT fatura_itens_pkey;
ALTER TABLE ONLY faturamento.eventos DROP CONSTRAINT eventos_pkey;
ALTER TABLE ONLY faturamento.evento_contratos DROP CONSTRAINT evento_contratos_pkey;
ALTER TABLE ONLY faturamento.empresas DROP CONSTRAINT empresas_pkey;
ALTER TABLE ONLY faturamento.contratos DROP CONSTRAINT contratos_pkey;
ALTER TABLE ONLY faturamento.contadores DROP CONSTRAINT contadores_pkey;
ALTER TABLE ONLY faturamento.clientes DROP CONSTRAINT clientes_pkey;
ALTER TABLE ONLY faturamento.chaves DROP CONSTRAINT chaves_pkey;
ALTER TABLE ONLY faturamento.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE ONLY faturamento.ajudas DROP CONSTRAINT ajudas_pkey;
ALTER TABLE public.tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ticket_movimentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ticket_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.produtos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.pessoas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.notificacoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.item_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.forma_pagamentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.faturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fatura_itens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.evento_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.clientes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.chaves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ajudas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.ticket_movimentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.ticket_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.produtos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.pessoas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.notificacoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.item_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.forma_pagamentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.faturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.fatura_itens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.evento_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.empresas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.contadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.clientes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.chaves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE minhascontas.ajudas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE kallario.pessoas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE kallario.faturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE kallario.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE kallario.empresas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE kallario.contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.ticket_movimentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.ticket_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.produtos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.pessoas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.notificacoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.item_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.forma_pagamentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.faturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.fatura_itens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.evento_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.empresas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.contadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.clientes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.chaves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE financeiro.ajudas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.ticket_movimentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.ticket_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.produtos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.pessoas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.notificacoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.item_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.forma_pagamentos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.faturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.fatura_itens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.evento_contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.empresas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.contratos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.contadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.clientes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.chaves ALTER COLUMN id DROP DEFAULT;
ALTER TABLE faturamento.ajudas ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.tickets_id_seq;
DROP TABLE public.tickets;
DROP SEQUENCE public.ticket_movimentos_id_seq;
DROP TABLE public.ticket_movimentos;
DROP SEQUENCE public.ticket_configs_id_seq;
DROP TABLE public.ticket_configs;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.produtos_id_seq;
DROP TABLE public.produtos;
DROP SEQUENCE public.pessoas_id_seq;
DROP TABLE public.pessoas;
DROP SEQUENCE public.notificacoes_id_seq;
DROP TABLE public.notificacoes;
DROP SEQUENCE public.item_contratos_id_seq;
DROP TABLE public.item_contratos;
DROP SEQUENCE public.grupos_id_seq;
DROP TABLE public.grupos;
DROP SEQUENCE public.forma_pagamentos_id_seq;
DROP TABLE public.forma_pagamentos;
DROP SEQUENCE public.faturas_id_seq;
DROP TABLE public.faturas;
DROP SEQUENCE public.fatura_itens_id_seq;
DROP TABLE public.fatura_itens;
DROP SEQUENCE public.eventos_id_seq;
DROP TABLE public.eventos;
DROP SEQUENCE public.evento_contratos_id_seq;
DROP TABLE public.evento_contratos;
DROP SEQUENCE public.empresas_id_seq;
DROP TABLE public.empresas;
DROP SEQUENCE public.contratos_id_seq;
DROP TABLE public.contratos;
DROP SEQUENCE public.contadores_id_seq;
DROP TABLE public.contadores;
DROP SEQUENCE public.clientes_id_seq;
DROP TABLE public.clientes;
DROP SEQUENCE public.chaves_id_seq;
DROP TABLE public.chaves;
DROP TABLE public.ar_internal_metadata;
DROP SEQUENCE public.ajudas_id_seq;
DROP TABLE public.ajudas;
DROP SEQUENCE minhascontas.tickets_id_seq;
DROP TABLE minhascontas.tickets;
DROP SEQUENCE minhascontas.ticket_movimentos_id_seq;
DROP TABLE minhascontas.ticket_movimentos;
DROP SEQUENCE minhascontas.ticket_configs_id_seq;
DROP TABLE minhascontas.ticket_configs;
DROP TABLE minhascontas.schema_migrations;
DROP SEQUENCE minhascontas.produtos_id_seq;
DROP TABLE minhascontas.produtos;
DROP SEQUENCE minhascontas.pessoas_id_seq;
DROP TABLE minhascontas.pessoas;
DROP SEQUENCE minhascontas.notificacoes_id_seq;
DROP TABLE minhascontas.notificacoes;
DROP SEQUENCE minhascontas.item_contratos_id_seq;
DROP TABLE minhascontas.item_contratos;
DROP SEQUENCE minhascontas.grupos_id_seq;
DROP TABLE minhascontas.grupos;
DROP SEQUENCE minhascontas.forma_pagamentos_id_seq;
DROP TABLE minhascontas.forma_pagamentos;
DROP SEQUENCE minhascontas.faturas_id_seq;
DROP TABLE minhascontas.faturas;
DROP SEQUENCE minhascontas.fatura_itens_id_seq;
DROP TABLE minhascontas.fatura_itens;
DROP SEQUENCE minhascontas.eventos_id_seq;
DROP TABLE minhascontas.eventos;
DROP SEQUENCE minhascontas.evento_contratos_id_seq;
DROP TABLE minhascontas.evento_contratos;
DROP SEQUENCE minhascontas.empresas_id_seq;
DROP TABLE minhascontas.empresas;
DROP SEQUENCE minhascontas.contratos_id_seq;
DROP TABLE minhascontas.contratos;
DROP SEQUENCE minhascontas.contadores_id_seq;
DROP TABLE minhascontas.contadores;
DROP SEQUENCE minhascontas.clientes_id_seq;
DROP TABLE minhascontas.clientes;
DROP SEQUENCE minhascontas.chaves_id_seq;
DROP TABLE minhascontas.chaves;
DROP TABLE minhascontas.ar_internal_metadata;
DROP SEQUENCE minhascontas.ajudas_id_seq;
DROP TABLE minhascontas.ajudas;
DROP TABLE kallario.schema_migrations;
DROP SEQUENCE kallario.pessoas_id_seq;
DROP TABLE kallario.pessoas;
DROP SEQUENCE kallario.faturas_id_seq;
DROP TABLE kallario.faturas;
DROP SEQUENCE kallario.eventos_id_seq;
DROP TABLE kallario.eventos;
DROP SEQUENCE kallario.empresas_id_seq;
DROP TABLE kallario.empresas;
DROP SEQUENCE kallario.contratos_id_seq;
DROP TABLE kallario.contratos;
DROP TABLE kallario.ar_internal_metadata;
DROP SEQUENCE financeiro.tickets_id_seq;
DROP TABLE financeiro.tickets;
DROP SEQUENCE financeiro.ticket_movimentos_id_seq;
DROP TABLE financeiro.ticket_movimentos;
DROP SEQUENCE financeiro.ticket_configs_id_seq;
DROP TABLE financeiro.ticket_configs;
DROP TABLE financeiro.schema_migrations;
DROP SEQUENCE financeiro.produtos_id_seq;
DROP TABLE financeiro.produtos;
DROP SEQUENCE financeiro.pessoas_id_seq;
DROP TABLE financeiro.pessoas;
DROP SEQUENCE financeiro.notificacoes_id_seq;
DROP TABLE financeiro.notificacoes;
DROP VIEW financeiro.listagem_faturas;
DROP SEQUENCE financeiro.item_contratos_id_seq;
DROP TABLE financeiro.item_contratos;
DROP SEQUENCE financeiro.grupos_id_seq;
DROP TABLE financeiro.grupos;
DROP SEQUENCE financeiro.forma_pagamentos_id_seq;
DROP TABLE financeiro.forma_pagamentos;
DROP SEQUENCE financeiro.faturas_id_seq;
DROP TABLE financeiro.faturas;
DROP SEQUENCE financeiro.fatura_itens_id_seq;
DROP TABLE financeiro.fatura_itens;
DROP SEQUENCE financeiro.eventos_id_seq;
DROP TABLE financeiro.eventos;
DROP SEQUENCE financeiro.evento_contratos_id_seq;
DROP TABLE financeiro.evento_contratos;
DROP SEQUENCE financeiro.empresas_id_seq;
DROP TABLE financeiro.empresas;
DROP SEQUENCE financeiro.contratos_id_seq;
DROP TABLE financeiro.contratos;
DROP SEQUENCE financeiro.contadores_id_seq;
DROP TABLE financeiro.contadores;
DROP SEQUENCE financeiro.clientes_id_seq;
DROP TABLE financeiro.clientes;
DROP SEQUENCE financeiro.chaves_id_seq;
DROP TABLE financeiro.chaves;
DROP TABLE financeiro.ar_internal_metadata;
DROP SEQUENCE financeiro.ajudas_id_seq;
DROP TABLE financeiro.ajudas;
DROP SEQUENCE faturamento.tickets_id_seq;
DROP TABLE faturamento.tickets;
DROP SEQUENCE faturamento.ticket_movimentos_id_seq;
DROP TABLE faturamento.ticket_movimentos;
DROP SEQUENCE faturamento.ticket_configs_id_seq;
DROP TABLE faturamento.ticket_configs;
DROP TABLE faturamento.schema_migrations;
DROP SEQUENCE faturamento.produtos_id_seq;
DROP TABLE faturamento.produtos;
DROP SEQUENCE faturamento.pessoas_id_seq;
DROP TABLE faturamento.pessoas;
DROP SEQUENCE faturamento.notificacoes_id_seq;
DROP TABLE faturamento.notificacoes;
DROP SEQUENCE faturamento.item_contratos_id_seq;
DROP TABLE faturamento.item_contratos;
DROP SEQUENCE faturamento.grupos_id_seq;
DROP TABLE faturamento.grupos;
DROP SEQUENCE faturamento.forma_pagamentos_id_seq;
DROP TABLE faturamento.forma_pagamentos;
DROP SEQUENCE faturamento.faturas_id_seq;
DROP TABLE faturamento.faturas;
DROP SEQUENCE faturamento.fatura_itens_id_seq;
DROP TABLE faturamento.fatura_itens;
DROP SEQUENCE faturamento.eventos_id_seq;
DROP TABLE faturamento.eventos;
DROP SEQUENCE faturamento.evento_contratos_id_seq;
DROP TABLE faturamento.evento_contratos;
DROP SEQUENCE faturamento.empresas_id_seq;
DROP TABLE faturamento.empresas;
DROP SEQUENCE faturamento.contratos_id_seq;
DROP TABLE faturamento.contratos;
DROP SEQUENCE faturamento.contadores_id_seq;
DROP TABLE faturamento.contadores;
DROP SEQUENCE faturamento.clientes_id_seq;
DROP TABLE faturamento.clientes;
DROP SEQUENCE faturamento.chaves_id_seq;
DROP TABLE faturamento.chaves;
DROP TABLE faturamento.ar_internal_metadata;
DROP SEQUENCE faturamento.ajudas_id_seq;
DROP TABLE faturamento.ajudas;
DROP EXTENSION unaccent;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA minhascontas;
DROP SCHEMA kallario;
DROP SCHEMA financeiro;
DROP SCHEMA faturamento;
DROP SCHEMA extensions;
--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: faturamento
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO faturamento;

--
-- Name: faturamento; Type: SCHEMA; Schema: -; Owner: faturamento
--

CREATE SCHEMA faturamento;


ALTER SCHEMA faturamento OWNER TO faturamento;

--
-- Name: financeiro; Type: SCHEMA; Schema: -; Owner: faturamento
--

CREATE SCHEMA financeiro;


ALTER SCHEMA financeiro OWNER TO faturamento;

--
-- Name: kallario; Type: SCHEMA; Schema: -; Owner: faturamento
--

CREATE SCHEMA kallario;


ALTER SCHEMA kallario OWNER TO faturamento;

--
-- Name: minhascontas; Type: SCHEMA; Schema: -; Owner: faturamento
--

CREATE SCHEMA minhascontas;


ALTER SCHEMA minhascontas OWNER TO faturamento;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA extensions;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ajudas; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.ajudas (
    id bigint NOT NULL,
    titulo character varying,
    descricao text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.ajudas OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.ajudas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.ajudas_id_seq OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.ajudas_id_seq OWNED BY faturamento.ajudas.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.ar_internal_metadata OWNER TO faturamento;

--
-- Name: chaves; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.chaves (
    id bigint NOT NULL,
    data date,
    password character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.chaves OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.chaves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.chaves_id_seq OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.chaves_id_seq OWNED BY faturamento.chaves.id;


--
-- Name: clientes; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.clientes (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    email character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    bloqueado smallint,
    token character varying,
    notifica smallint
);


ALTER TABLE faturamento.clientes OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.clientes_id_seq OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.clientes_id_seq OWNED BY faturamento.clientes.id;


--
-- Name: contadores; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.contadores (
    id bigint NOT NULL,
    nome_escritorio character varying,
    nome_contador character varying,
    crc character varying,
    municipio character varying,
    uf character varying,
    telefone character varying,
    celular character varying,
    whatsapp character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.contadores OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.contadores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.contadores_id_seq OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.contadores_id_seq OWNED BY faturamento.contadores.id;


--
-- Name: contratos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.contratos (
    id bigint NOT NULL,
    data_inicio_contrato date,
    data_termino_contrato date,
    tipo_contrato smallint,
    descricao text,
    dia_vencimento smallint,
    valor_cobrado numeric(8,2),
    multa numeric(8,2),
    juros numeric(8,2),
    tipo_juros smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    forma_pagamento_id bigint,
    cliente_id bigint,
    url_slip_pdf character varying
);


ALTER TABLE faturamento.contratos OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.contratos_id_seq OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.contratos_id_seq OWNED BY faturamento.contratos.id;


--
-- Name: empresas; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.empresas (
    id bigint NOT NULL,
    nome character varying,
    cnpj character varying,
    telefone character varying,
    endereco character varying,
    bairro character varying,
    cidade character varying,
    cep character varying,
    subdomain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying
);


ALTER TABLE faturamento.empresas OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.empresas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.empresas_id_seq OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.empresas_id_seq OWNED BY faturamento.empresas.id;


--
-- Name: evento_contratos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.evento_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    valor_contrato numeric,
    data_inicio_evento date,
    periodo integer,
    motivo text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.evento_contratos OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.evento_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.evento_contratos_id_seq OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.evento_contratos_id_seq OWNED BY faturamento.evento_contratos.id;


--
-- Name: eventos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.eventos (
    id bigint NOT NULL,
    fatura_id bigint,
    pessoa_id bigint,
    data date,
    valor numeric,
    tipo_evento smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    observacao text,
    forma_pagamento_id bigint,
    desconto numeric
);


ALTER TABLE faturamento.eventos OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.eventos_id_seq OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.eventos_id_seq OWNED BY faturamento.eventos.id;


--
-- Name: fatura_itens; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.fatura_itens (
    id bigint NOT NULL,
    fatura_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data date,
    pessoa_id bigint,
    parcelado integer DEFAULT 1 NOT NULL
);


ALTER TABLE faturamento.fatura_itens OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.fatura_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.fatura_itens_id_seq OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.fatura_itens_id_seq OWNED BY faturamento.fatura_itens.id;


--
-- Name: faturas; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.faturas (
    id bigint NOT NULL,
    contrato_id bigint,
    vencimento date,
    valor_fatura numeric,
    situacao smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    acrescimos numeric DEFAULT 0.0 NOT NULL,
    descontos numeric DEFAULT 0.0 NOT NULL,
    total_pago numeric DEFAULT 0.0 NOT NULL,
    transaction_id character varying,
    url_slip_pdf character varying,
    due_date date,
    status character varying,
    order_id character varying
);


ALTER TABLE faturamento.faturas OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.faturas_id_seq OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.faturas_id_seq OWNED BY faturamento.faturas.id;


--
-- Name: forma_pagamentos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.forma_pagamentos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    instrucoes text,
    emite_boleto smallint DEFAULT 0 NOT NULL,
    dia_emissao_boletos integer,
    type_bank_slip character varying,
    fixed_description smallint,
    late_payment_fine smallint,
    per_day_interest smallint,
    early_payment_discounts_days smallint,
    early_payment_discounts_cents integer,
    open_after_day_due smallint
);


ALTER TABLE faturamento.forma_pagamentos OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.forma_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.forma_pagamentos_id_seq OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.forma_pagamentos_id_seq OWNED BY faturamento.forma_pagamentos.id;


--
-- Name: grupos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.grupos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.grupos OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.grupos_id_seq OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.grupos_id_seq OWNED BY faturamento.grupos.id;


--
-- Name: item_contratos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.item_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.item_contratos OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.item_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.item_contratos_id_seq OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.item_contratos_id_seq OWNED BY faturamento.item_contratos.id;


--
-- Name: notificacoes; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.notificacoes (
    id bigint NOT NULL,
    recipiente_id integer,
    autor_id integer,
    lido_em timestamp without time zone,
    assunto character varying,
    notificacao_id smallint,
    notificacao_tipo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.notificacoes OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.notificacoes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.notificacoes_id_seq OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.notificacoes_id_seq OWNED BY faturamento.notificacoes.id;


--
-- Name: pessoas; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.pessoas (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    bloqueado smallint,
    notifica smallint
);


ALTER TABLE faturamento.pessoas OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.pessoas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.pessoas_id_seq OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.pessoas_id_seq OWNED BY faturamento.pessoas.id;


--
-- Name: produtos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.produtos (
    id bigint NOT NULL,
    grupo_id bigint,
    descricao character varying,
    unidade character varying,
    marca character varying,
    modelo character varying,
    preco_custo numeric,
    preco_venda numeric,
    estoque_inicial numeric,
    estoque_entrada numeric,
    estoque_saida numeric,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    controla_estoque smallint
);


ALTER TABLE faturamento.produtos OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.produtos_id_seq OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.produtos_id_seq OWNED BY faturamento.produtos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE faturamento.schema_migrations OWNER TO faturamento;

--
-- Name: ticket_configs; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.ticket_configs (
    id bigint NOT NULL,
    dias_resposta smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.ticket_configs OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.ticket_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.ticket_configs_id_seq OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.ticket_configs_id_seq OWNED BY faturamento.ticket_configs.id;


--
-- Name: ticket_movimentos; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.ticket_movimentos (
    id bigint NOT NULL,
    ticket_id bigint,
    data_movimento timestamp without time zone,
    tipo_movimento smallint,
    observacoes text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.ticket_movimentos OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.ticket_movimentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.ticket_movimentos_id_seq OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.ticket_movimentos_id_seq OWNED BY faturamento.ticket_movimentos.id;


--
-- Name: tickets; Type: TABLE; Schema: faturamento; Owner: faturamento
--

CREATE TABLE faturamento.tickets (
    id bigint NOT NULL,
    cliente_id bigint,
    data_abertura timestamp without time zone,
    assunto character varying,
    solicitacao_texto text,
    status smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE faturamento.tickets OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: faturamento; Owner: faturamento
--

CREATE SEQUENCE faturamento.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE faturamento.tickets_id_seq OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: faturamento; Owner: faturamento
--

ALTER SEQUENCE faturamento.tickets_id_seq OWNED BY faturamento.tickets.id;


--
-- Name: ajudas; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.ajudas (
    id bigint NOT NULL,
    titulo character varying,
    descricao text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.ajudas OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.ajudas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.ajudas_id_seq OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.ajudas_id_seq OWNED BY financeiro.ajudas.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.ar_internal_metadata OWNER TO faturamento;

--
-- Name: chaves; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.chaves (
    id bigint NOT NULL,
    data date,
    password character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.chaves OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.chaves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.chaves_id_seq OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.chaves_id_seq OWNED BY financeiro.chaves.id;


--
-- Name: clientes; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.clientes (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    pessoa_id bigint,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying(255),
    bloqueado smallint,
    token character varying,
    notifica smallint
);


ALTER TABLE financeiro.clientes OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.clientes_id_seq OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.clientes_id_seq OWNED BY financeiro.clientes.id;


--
-- Name: contadores; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.contadores (
    id bigint NOT NULL,
    nome_escritorio character varying,
    nome_contador character varying,
    crc character varying,
    municipio character varying,
    uf character varying,
    telefone character varying,
    celular character varying,
    whatsapp character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.contadores OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.contadores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.contadores_id_seq OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.contadores_id_seq OWNED BY financeiro.contadores.id;


--
-- Name: contratos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.contratos (
    id bigint NOT NULL,
    data_inicio_contrato date,
    data_termino_contrato date,
    tipo_contrato smallint,
    descricao text,
    dia_vencimento smallint,
    valor_cobrado numeric(8,2),
    multa numeric(8,2),
    juros numeric(8,2),
    tipo_juros smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    forma_pagamento_id bigint,
    cliente_id bigint,
    url_slip_pdf character varying
);


ALTER TABLE financeiro.contratos OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.contratos_id_seq OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.contratos_id_seq OWNED BY financeiro.contratos.id;


--
-- Name: empresas; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.empresas (
    id bigint NOT NULL,
    nome character varying,
    cnpj character varying,
    telefone character varying,
    endereco character varying,
    bairro character varying,
    cidade character varying,
    cep character varying,
    subdomain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying
);


ALTER TABLE financeiro.empresas OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.empresas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.empresas_id_seq OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.empresas_id_seq OWNED BY financeiro.empresas.id;


--
-- Name: evento_contratos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.evento_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    valor_contrato numeric,
    data_inicio_evento date,
    periodo integer,
    motivo text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.evento_contratos OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.evento_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.evento_contratos_id_seq OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.evento_contratos_id_seq OWNED BY financeiro.evento_contratos.id;


--
-- Name: eventos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.eventos (
    id bigint NOT NULL,
    fatura_id bigint,
    pessoa_id bigint,
    data date,
    valor numeric,
    tipo_evento smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    observacao text,
    forma_pagamento_id bigint,
    desconto numeric
);


ALTER TABLE financeiro.eventos OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.eventos_id_seq OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.eventos_id_seq OWNED BY financeiro.eventos.id;


--
-- Name: fatura_itens; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.fatura_itens (
    id bigint NOT NULL,
    fatura_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data date,
    pessoa_id bigint,
    parcelado integer DEFAULT 1 NOT NULL
);


ALTER TABLE financeiro.fatura_itens OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.fatura_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.fatura_itens_id_seq OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.fatura_itens_id_seq OWNED BY financeiro.fatura_itens.id;


--
-- Name: faturas; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.faturas (
    id bigint NOT NULL,
    contrato_id bigint,
    vencimento date,
    valor_fatura numeric,
    situacao smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    acrescimos numeric DEFAULT 0 NOT NULL,
    descontos numeric DEFAULT 0 NOT NULL,
    total_pago numeric DEFAULT 0 NOT NULL,
    transaction_id character varying,
    url_slip_pdf character varying,
    due_date date,
    status character varying,
    order_id character varying
);


ALTER TABLE financeiro.faturas OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.faturas_id_seq OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.faturas_id_seq OWNED BY financeiro.faturas.id;


--
-- Name: forma_pagamentos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.forma_pagamentos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    instrucoes text,
    emite_boleto smallint DEFAULT 0 NOT NULL,
    dia_emissao_boletos integer,
    type_bank_slip character varying,
    fixed_description smallint,
    late_payment_fine smallint,
    per_day_interest smallint,
    early_payment_discounts_days smallint,
    early_payment_discounts_cents integer,
    open_after_day_due smallint
);


ALTER TABLE financeiro.forma_pagamentos OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.forma_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.forma_pagamentos_id_seq OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.forma_pagamentos_id_seq OWNED BY financeiro.forma_pagamentos.id;


--
-- Name: grupos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.grupos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.grupos OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.grupos_id_seq OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.grupos_id_seq OWNED BY financeiro.grupos.id;


--
-- Name: item_contratos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.item_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.item_contratos OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.item_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.item_contratos_id_seq OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.item_contratos_id_seq OWNED BY financeiro.item_contratos.id;


--
-- Name: listagem_faturas; Type: VIEW; Schema: financeiro; Owner: luiz
--

CREATE VIEW financeiro.listagem_faturas AS
 SELECT clientes.nome,
    clientes.ativo,
    clientes.grupo,
    contratos.data_inicio_contrato,
    faturas.vencimento,
    faturas.situacao,
    contratos.forma_pagamento_id,
    forma_pagamentos.emite_boleto,
    clientes.cidade,
    faturas.valor_fatura,
    faturas.acrescimos,
    faturas.descontos,
    faturas.total_pago,
    faturas.transaction_id,
    forma_pagamentos.descricao,
    faturas.contrato_id,
    contratos.cliente_id,
    faturas.id
   FROM (((financeiro.clientes
     JOIN financeiro.contratos ON ((contratos.cliente_id = clientes.id)))
     JOIN financeiro.faturas ON ((faturas.contrato_id = contratos.id)))
     JOIN financeiro.forma_pagamentos ON ((contratos.forma_pagamento_id = forma_pagamentos.id)));


ALTER TABLE financeiro.listagem_faturas OWNER TO luiz;

--
-- Name: notificacoes; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.notificacoes (
    id bigint NOT NULL,
    recipiente_id integer,
    autor_id integer,
    lido_em timestamp without time zone,
    assunto character varying,
    notificacao_id smallint,
    notificacao_tipo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.notificacoes OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.notificacoes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.notificacoes_id_seq OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.notificacoes_id_seq OWNED BY financeiro.notificacoes.id;


--
-- Name: pessoas; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.pessoas (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    bloqueado smallint,
    notifica smallint
);


ALTER TABLE financeiro.pessoas OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.pessoas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.pessoas_id_seq OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.pessoas_id_seq OWNED BY financeiro.pessoas.id;


--
-- Name: produtos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.produtos (
    id bigint NOT NULL,
    grupo_id bigint,
    descricao character varying,
    unidade character varying,
    marca character varying,
    modelo character varying,
    preco_custo numeric,
    preco_venda numeric,
    estoque_inicial numeric,
    estoque_entrada numeric,
    estoque_saida numeric,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    controla_estoque smallint
);


ALTER TABLE financeiro.produtos OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.produtos_id_seq OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.produtos_id_seq OWNED BY financeiro.produtos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE financeiro.schema_migrations OWNER TO faturamento;

--
-- Name: ticket_configs; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.ticket_configs (
    id bigint NOT NULL,
    dias_resposta smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.ticket_configs OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.ticket_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.ticket_configs_id_seq OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.ticket_configs_id_seq OWNED BY financeiro.ticket_configs.id;


--
-- Name: ticket_movimentos; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.ticket_movimentos (
    id bigint NOT NULL,
    ticket_id bigint,
    data_movimento timestamp without time zone,
    tipo_movimento smallint,
    observacoes text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.ticket_movimentos OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.ticket_movimentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.ticket_movimentos_id_seq OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.ticket_movimentos_id_seq OWNED BY financeiro.ticket_movimentos.id;


--
-- Name: tickets; Type: TABLE; Schema: financeiro; Owner: faturamento
--

CREATE TABLE financeiro.tickets (
    id bigint NOT NULL,
    cliente_id bigint,
    data_abertura timestamp without time zone,
    assunto character varying,
    solicitacao_texto text,
    status smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE financeiro.tickets OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: financeiro; Owner: faturamento
--

CREATE SEQUENCE financeiro.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE financeiro.tickets_id_seq OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: financeiro; Owner: faturamento
--

ALTER SEQUENCE financeiro.tickets_id_seq OWNED BY financeiro.tickets.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE kallario.ar_internal_metadata OWNER TO faturamento;

--
-- Name: contratos; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.contratos (
    id bigint NOT NULL,
    pessoa_id bigint,
    data_inicio_contrato date,
    data_termino_contrato date,
    tipo_contrato smallint,
    descricao text,
    dia_vencimento smallint,
    valor_cobrado numeric(8,2),
    multa numeric(8,2),
    juros numeric(8,2),
    tipo_juros smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE kallario.contratos OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE; Schema: kallario; Owner: faturamento
--

CREATE SEQUENCE kallario.contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kallario.contratos_id_seq OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: kallario; Owner: faturamento
--

ALTER SEQUENCE kallario.contratos_id_seq OWNED BY kallario.contratos.id;


--
-- Name: empresas; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.empresas (
    id bigint NOT NULL,
    nome character varying,
    cnpj character varying,
    telefone character varying,
    endereco character varying,
    bairro character varying,
    cidade character varying,
    cep character varying,
    subdomain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying
);


ALTER TABLE kallario.empresas OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE; Schema: kallario; Owner: faturamento
--

CREATE SEQUENCE kallario.empresas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kallario.empresas_id_seq OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE OWNED BY; Schema: kallario; Owner: faturamento
--

ALTER SEQUENCE kallario.empresas_id_seq OWNED BY kallario.empresas.id;


--
-- Name: eventos; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.eventos (
    id bigint NOT NULL,
    fatura_id bigint,
    pessoa_id bigint,
    data date,
    valor numeric,
    forma_pagamento smallint,
    tipo_evento smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    observacao text
);


ALTER TABLE kallario.eventos OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: kallario; Owner: faturamento
--

CREATE SEQUENCE kallario.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kallario.eventos_id_seq OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: kallario; Owner: faturamento
--

ALTER SEQUENCE kallario.eventos_id_seq OWNED BY kallario.eventos.id;


--
-- Name: faturas; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.faturas (
    id bigint NOT NULL,
    contrato_id bigint,
    vencimento date,
    valor_fatura numeric,
    situacao smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE kallario.faturas OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE; Schema: kallario; Owner: faturamento
--

CREATE SEQUENCE kallario.faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kallario.faturas_id_seq OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: kallario; Owner: faturamento
--

ALTER SEQUENCE kallario.faturas_id_seq OWNED BY kallario.faturas.id;


--
-- Name: pessoas; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.pessoas (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet
);


ALTER TABLE kallario.pessoas OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE; Schema: kallario; Owner: faturamento
--

CREATE SEQUENCE kallario.pessoas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kallario.pessoas_id_seq OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE OWNED BY; Schema: kallario; Owner: faturamento
--

ALTER SEQUENCE kallario.pessoas_id_seq OWNED BY kallario.pessoas.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: kallario; Owner: faturamento
--

CREATE TABLE kallario.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE kallario.schema_migrations OWNER TO faturamento;

--
-- Name: ajudas; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.ajudas (
    id bigint NOT NULL,
    titulo character varying,
    descricao text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.ajudas OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.ajudas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.ajudas_id_seq OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.ajudas_id_seq OWNED BY minhascontas.ajudas.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.ar_internal_metadata OWNER TO faturamento;

--
-- Name: chaves; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.chaves (
    id bigint NOT NULL,
    data date,
    password character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.chaves OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.chaves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.chaves_id_seq OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.chaves_id_seq OWNED BY minhascontas.chaves.id;


--
-- Name: clientes; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.clientes (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    pessoa_id bigint,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    bloqueado smallint,
    token character varying
);


ALTER TABLE minhascontas.clientes OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.clientes_id_seq OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.clientes_id_seq OWNED BY minhascontas.clientes.id;


--
-- Name: contadores; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.contadores (
    id bigint NOT NULL,
    nome_escritorio character varying,
    nome_contador character varying,
    crc character varying,
    municipio character varying,
    uf character varying,
    telefone character varying,
    celular character varying,
    whatsapp character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.contadores OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.contadores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.contadores_id_seq OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.contadores_id_seq OWNED BY minhascontas.contadores.id;


--
-- Name: contratos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.contratos (
    id bigint NOT NULL,
    data_inicio_contrato date,
    data_termino_contrato date,
    tipo_contrato smallint,
    descricao text,
    dia_vencimento smallint,
    valor_cobrado numeric(8,2),
    multa numeric(8,2),
    juros numeric(8,2),
    tipo_juros smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    forma_pagamento_id bigint,
    cliente_id bigint,
    url_slip_pdf character varying
);


ALTER TABLE minhascontas.contratos OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.contratos_id_seq OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.contratos_id_seq OWNED BY minhascontas.contratos.id;


--
-- Name: empresas; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.empresas (
    id bigint NOT NULL,
    nome character varying,
    cnpj character varying,
    telefone character varying,
    endereco character varying,
    bairro character varying,
    cidade character varying,
    cep character varying,
    subdomain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying
);


ALTER TABLE minhascontas.empresas OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.empresas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.empresas_id_seq OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.empresas_id_seq OWNED BY minhascontas.empresas.id;


--
-- Name: evento_contratos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.evento_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    valor_contrato numeric,
    data_inicio_evento date,
    periodo integer,
    motivo text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.evento_contratos OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.evento_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.evento_contratos_id_seq OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.evento_contratos_id_seq OWNED BY minhascontas.evento_contratos.id;


--
-- Name: eventos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.eventos (
    id bigint NOT NULL,
    fatura_id bigint,
    pessoa_id bigint,
    data date,
    valor numeric,
    tipo_evento smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    observacao text,
    forma_pagamento_id bigint,
    desconto numeric
);


ALTER TABLE minhascontas.eventos OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.eventos_id_seq OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.eventos_id_seq OWNED BY minhascontas.eventos.id;


--
-- Name: fatura_itens; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.fatura_itens (
    id bigint NOT NULL,
    fatura_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data date,
    pessoa_id bigint,
    parcelado integer DEFAULT 1 NOT NULL
);


ALTER TABLE minhascontas.fatura_itens OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.fatura_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.fatura_itens_id_seq OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.fatura_itens_id_seq OWNED BY minhascontas.fatura_itens.id;


--
-- Name: faturas; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.faturas (
    id bigint NOT NULL,
    contrato_id bigint,
    vencimento date,
    valor_fatura numeric,
    situacao smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    acrescimos numeric DEFAULT 0 NOT NULL,
    descontos numeric DEFAULT 0 NOT NULL,
    total_pago numeric DEFAULT 0 NOT NULL,
    transaction_id character varying,
    url_slip_pdf character varying,
    due_date date,
    status character varying,
    order_id character varying
);


ALTER TABLE minhascontas.faturas OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.faturas_id_seq OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.faturas_id_seq OWNED BY minhascontas.faturas.id;


--
-- Name: forma_pagamentos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.forma_pagamentos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    instrucoes text,
    emite_boleto smallint DEFAULT 0 NOT NULL,
    dia_emissao_boletos integer,
    type_bank_slip character varying,
    fixed_description smallint,
    late_payment_fine smallint,
    per_day_interest smallint,
    early_payment_discounts_days smallint,
    early_payment_discounts_cents integer,
    open_after_day_due smallint
);


ALTER TABLE minhascontas.forma_pagamentos OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.forma_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.forma_pagamentos_id_seq OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.forma_pagamentos_id_seq OWNED BY minhascontas.forma_pagamentos.id;


--
-- Name: grupos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.grupos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.grupos OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.grupos_id_seq OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.grupos_id_seq OWNED BY minhascontas.grupos.id;


--
-- Name: item_contratos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.item_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.item_contratos OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.item_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.item_contratos_id_seq OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.item_contratos_id_seq OWNED BY minhascontas.item_contratos.id;


--
-- Name: notificacoes; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.notificacoes (
    id bigint NOT NULL,
    recipiente_id integer,
    autor_id integer,
    lido_em timestamp without time zone,
    assunto character varying,
    notificacao_id smallint,
    notificacao_tipo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.notificacoes OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.notificacoes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.notificacoes_id_seq OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.notificacoes_id_seq OWNED BY minhascontas.notificacoes.id;


--
-- Name: pessoas; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.pessoas (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    bloqueado smallint
);


ALTER TABLE minhascontas.pessoas OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.pessoas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.pessoas_id_seq OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.pessoas_id_seq OWNED BY minhascontas.pessoas.id;


--
-- Name: produtos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.produtos (
    id bigint NOT NULL,
    grupo_id bigint,
    descricao character varying,
    unidade character varying,
    marca character varying,
    modelo character varying,
    preco_custo numeric,
    preco_venda numeric,
    estoque_inicial numeric,
    estoque_entrada numeric,
    estoque_saida numeric,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    controla_estoque smallint
);


ALTER TABLE minhascontas.produtos OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.produtos_id_seq OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.produtos_id_seq OWNED BY minhascontas.produtos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE minhascontas.schema_migrations OWNER TO faturamento;

--
-- Name: ticket_configs; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.ticket_configs (
    id bigint NOT NULL,
    dias_resposta smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.ticket_configs OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.ticket_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.ticket_configs_id_seq OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.ticket_configs_id_seq OWNED BY minhascontas.ticket_configs.id;


--
-- Name: ticket_movimentos; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.ticket_movimentos (
    id bigint NOT NULL,
    ticket_id bigint,
    data_movimento timestamp without time zone,
    tipo_movimento smallint,
    observacoes text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.ticket_movimentos OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.ticket_movimentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.ticket_movimentos_id_seq OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.ticket_movimentos_id_seq OWNED BY minhascontas.ticket_movimentos.id;


--
-- Name: tickets; Type: TABLE; Schema: minhascontas; Owner: faturamento
--

CREATE TABLE minhascontas.tickets (
    id bigint NOT NULL,
    cliente_id bigint,
    data_abertura timestamp without time zone,
    assunto character varying,
    solicitacao_texto text,
    status smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE minhascontas.tickets OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: minhascontas; Owner: faturamento
--

CREATE SEQUENCE minhascontas.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minhascontas.tickets_id_seq OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: minhascontas; Owner: faturamento
--

ALTER SEQUENCE minhascontas.tickets_id_seq OWNED BY minhascontas.tickets.id;


--
-- Name: ajudas; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.ajudas (
    id bigint NOT NULL,
    titulo character varying,
    descricao text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ajudas OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.ajudas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ajudas_id_seq OWNER TO faturamento;

--
-- Name: ajudas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.ajudas_id_seq OWNED BY public.ajudas.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO faturamento;

--
-- Name: chaves; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.chaves (
    id bigint NOT NULL,
    data date,
    password character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.chaves OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.chaves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chaves_id_seq OWNER TO faturamento;

--
-- Name: chaves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.chaves_id_seq OWNED BY public.chaves.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    pessoa_id bigint,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    bloqueado smallint,
    token character varying
);


ALTER TABLE public.clientes OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_id_seq OWNER TO faturamento;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: contadores; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.contadores (
    id bigint NOT NULL,
    nome_escritorio character varying,
    nome_contador character varying,
    crc character varying,
    municipio character varying,
    uf character varying,
    telefone character varying,
    celular character varying,
    whatsapp character varying,
    email character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.contadores OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.contadores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contadores_id_seq OWNER TO faturamento;

--
-- Name: contadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.contadores_id_seq OWNED BY public.contadores.id;


--
-- Name: contratos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.contratos (
    id bigint NOT NULL,
    data_inicio_contrato date,
    data_termino_contrato date,
    tipo_contrato smallint,
    descricao text,
    dia_vencimento smallint,
    valor_cobrado numeric(8,2),
    multa numeric(8,2),
    juros numeric(8,2),
    tipo_juros smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    forma_pagamento_id bigint,
    cliente_id bigint,
    url_slip_pdf character varying
);


ALTER TABLE public.contratos OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contratos_id_seq OWNER TO faturamento;

--
-- Name: contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.contratos_id_seq OWNED BY public.contratos.id;


--
-- Name: empresas; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.empresas (
    id bigint NOT NULL,
    nome character varying,
    cnpj character varying,
    telefone character varying,
    endereco character varying,
    bairro character varying,
    cidade character varying,
    cep character varying,
    subdomain character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying
);


ALTER TABLE public.empresas OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.empresas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresas_id_seq OWNER TO faturamento;

--
-- Name: empresas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.empresas_id_seq OWNED BY public.empresas.id;


--
-- Name: evento_contratos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.evento_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    valor_contrato numeric,
    data_inicio_evento date,
    periodo integer,
    motivo text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.evento_contratos OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.evento_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.evento_contratos_id_seq OWNER TO faturamento;

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.evento_contratos_id_seq OWNED BY public.evento_contratos.id;


--
-- Name: eventos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.eventos (
    id bigint NOT NULL,
    fatura_id bigint,
    pessoa_id bigint,
    data date,
    valor numeric,
    tipo_evento smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    observacao text,
    forma_pagamento_id bigint,
    desconto numeric
);


ALTER TABLE public.eventos OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.eventos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.eventos_id_seq OWNER TO faturamento;

--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.eventos_id_seq OWNED BY public.eventos.id;


--
-- Name: fatura_itens; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.fatura_itens (
    id bigint NOT NULL,
    fatura_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    data date,
    pessoa_id bigint,
    parcelado integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.fatura_itens OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.fatura_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fatura_itens_id_seq OWNER TO faturamento;

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.fatura_itens_id_seq OWNED BY public.fatura_itens.id;


--
-- Name: faturas; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.faturas (
    id bigint NOT NULL,
    contrato_id bigint,
    vencimento date,
    valor_fatura numeric,
    situacao smallint,
    observacoes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    acrescimos numeric DEFAULT 0 NOT NULL,
    descontos numeric DEFAULT 0 NOT NULL,
    total_pago numeric DEFAULT 0 NOT NULL,
    transaction_id character varying,
    url_slip_pdf character varying,
    due_date date,
    status character varying,
    order_id character varying
);


ALTER TABLE public.faturas OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faturas_id_seq OWNER TO faturamento;

--
-- Name: faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.faturas_id_seq OWNED BY public.faturas.id;


--
-- Name: forma_pagamentos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.forma_pagamentos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    instrucoes text,
    emite_boleto smallint DEFAULT 0 NOT NULL,
    dia_emissao_boletos integer,
    type_bank_slip character varying,
    fixed_description smallint,
    late_payment_fine smallint,
    per_day_interest smallint,
    early_payment_discounts_days smallint,
    early_payment_discounts_cents integer,
    open_after_day_due smallint
);


ALTER TABLE public.forma_pagamentos OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.forma_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forma_pagamentos_id_seq OWNER TO faturamento;

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.forma_pagamentos_id_seq OWNED BY public.forma_pagamentos.id;


--
-- Name: grupos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.grupos (
    id bigint NOT NULL,
    descricao character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grupos OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupos_id_seq OWNER TO faturamento;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.grupos_id_seq OWNED BY public.grupos.id;


--
-- Name: item_contratos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.item_contratos (
    id bigint NOT NULL,
    contrato_id bigint,
    produto_id bigint,
    quantidade numeric,
    preco_unitario numeric,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.item_contratos OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.item_contratos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_contratos_id_seq OWNER TO faturamento;

--
-- Name: item_contratos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.item_contratos_id_seq OWNED BY public.item_contratos.id;


--
-- Name: notificacoes; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.notificacoes (
    id bigint NOT NULL,
    recipiente_id integer,
    autor_id integer,
    lido_em timestamp without time zone,
    assunto character varying,
    notificacao_id smallint,
    notificacao_tipo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.notificacoes OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.notificacoes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notificacoes_id_seq OWNER TO faturamento;

--
-- Name: notificacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.notificacoes_id_seq OWNED BY public.notificacoes.id;


--
-- Name: pessoas; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.pessoas (
    id bigint NOT NULL,
    nome character varying,
    tipo_pessoa smallint,
    numero_cadastro_pessoa character varying,
    logradouro character varying,
    numero character varying,
    complemento character varying,
    bairro character varying,
    cidade character varying,
    estado character varying,
    cep character varying,
    telefone character varying,
    celular character varying,
    grupo smallint,
    cadastrado_em date,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    latitude character varying,
    longitude character varying,
    nome_fantasia character varying,
    contato character varying,
    inscricao_estadual character varying,
    inscricao_municipal character varying,
    whatsapp character varying,
    contador_id bigint,
    bloqueado smallint
);


ALTER TABLE public.pessoas OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.pessoas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pessoas_id_seq OWNER TO faturamento;

--
-- Name: pessoas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.pessoas_id_seq OWNED BY public.pessoas.id;


--
-- Name: produtos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.produtos (
    id bigint NOT NULL,
    grupo_id bigint,
    descricao character varying,
    unidade character varying,
    marca character varying,
    modelo character varying,
    preco_custo numeric,
    preco_venda numeric,
    estoque_inicial numeric,
    estoque_entrada numeric,
    estoque_saida numeric,
    ativo smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    controla_estoque smallint
);


ALTER TABLE public.produtos OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produtos_id_seq OWNER TO faturamento;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.produtos_id_seq OWNED BY public.produtos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO faturamento;

--
-- Name: ticket_configs; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.ticket_configs (
    id bigint NOT NULL,
    dias_resposta smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ticket_configs OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.ticket_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_configs_id_seq OWNER TO faturamento;

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.ticket_configs_id_seq OWNED BY public.ticket_configs.id;


--
-- Name: ticket_movimentos; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.ticket_movimentos (
    id bigint NOT NULL,
    ticket_id bigint,
    data_movimento timestamp without time zone,
    tipo_movimento smallint,
    observacoes text,
    pessoa_id bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ticket_movimentos OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.ticket_movimentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_movimentos_id_seq OWNER TO faturamento;

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.ticket_movimentos_id_seq OWNED BY public.ticket_movimentos.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: faturamento
--

CREATE TABLE public.tickets (
    id bigint NOT NULL,
    cliente_id bigint,
    data_abertura timestamp without time zone,
    assunto character varying,
    solicitacao_texto text,
    status smallint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tickets OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: faturamento
--

CREATE SEQUENCE public.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tickets_id_seq OWNER TO faturamento;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faturamento
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ajudas ALTER COLUMN id SET DEFAULT nextval('faturamento.ajudas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.chaves ALTER COLUMN id SET DEFAULT nextval('faturamento.chaves_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.clientes ALTER COLUMN id SET DEFAULT nextval('faturamento.clientes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contadores ALTER COLUMN id SET DEFAULT nextval('faturamento.contadores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contratos ALTER COLUMN id SET DEFAULT nextval('faturamento.contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.empresas ALTER COLUMN id SET DEFAULT nextval('faturamento.empresas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.evento_contratos ALTER COLUMN id SET DEFAULT nextval('faturamento.evento_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.eventos ALTER COLUMN id SET DEFAULT nextval('faturamento.eventos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.fatura_itens ALTER COLUMN id SET DEFAULT nextval('faturamento.fatura_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.faturas ALTER COLUMN id SET DEFAULT nextval('faturamento.faturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.forma_pagamentos ALTER COLUMN id SET DEFAULT nextval('faturamento.forma_pagamentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.grupos ALTER COLUMN id SET DEFAULT nextval('faturamento.grupos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.item_contratos ALTER COLUMN id SET DEFAULT nextval('faturamento.item_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.notificacoes ALTER COLUMN id SET DEFAULT nextval('faturamento.notificacoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.pessoas ALTER COLUMN id SET DEFAULT nextval('faturamento.pessoas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.produtos ALTER COLUMN id SET DEFAULT nextval('faturamento.produtos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_configs ALTER COLUMN id SET DEFAULT nextval('faturamento.ticket_configs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_movimentos ALTER COLUMN id SET DEFAULT nextval('faturamento.ticket_movimentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.tickets ALTER COLUMN id SET DEFAULT nextval('faturamento.tickets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ajudas ALTER COLUMN id SET DEFAULT nextval('financeiro.ajudas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.chaves ALTER COLUMN id SET DEFAULT nextval('financeiro.chaves_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.clientes ALTER COLUMN id SET DEFAULT nextval('financeiro.clientes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contadores ALTER COLUMN id SET DEFAULT nextval('financeiro.contadores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contratos ALTER COLUMN id SET DEFAULT nextval('financeiro.contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.empresas ALTER COLUMN id SET DEFAULT nextval('financeiro.empresas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.evento_contratos ALTER COLUMN id SET DEFAULT nextval('financeiro.evento_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.eventos ALTER COLUMN id SET DEFAULT nextval('financeiro.eventos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.fatura_itens ALTER COLUMN id SET DEFAULT nextval('financeiro.fatura_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.faturas ALTER COLUMN id SET DEFAULT nextval('financeiro.faturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.forma_pagamentos ALTER COLUMN id SET DEFAULT nextval('financeiro.forma_pagamentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.grupos ALTER COLUMN id SET DEFAULT nextval('financeiro.grupos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.item_contratos ALTER COLUMN id SET DEFAULT nextval('financeiro.item_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.notificacoes ALTER COLUMN id SET DEFAULT nextval('financeiro.notificacoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.pessoas ALTER COLUMN id SET DEFAULT nextval('financeiro.pessoas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.produtos ALTER COLUMN id SET DEFAULT nextval('financeiro.produtos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_configs ALTER COLUMN id SET DEFAULT nextval('financeiro.ticket_configs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_movimentos ALTER COLUMN id SET DEFAULT nextval('financeiro.ticket_movimentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.tickets ALTER COLUMN id SET DEFAULT nextval('financeiro.tickets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.contratos ALTER COLUMN id SET DEFAULT nextval('kallario.contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.empresas ALTER COLUMN id SET DEFAULT nextval('kallario.empresas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.eventos ALTER COLUMN id SET DEFAULT nextval('kallario.eventos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.faturas ALTER COLUMN id SET DEFAULT nextval('kallario.faturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.pessoas ALTER COLUMN id SET DEFAULT nextval('kallario.pessoas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ajudas ALTER COLUMN id SET DEFAULT nextval('minhascontas.ajudas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.chaves ALTER COLUMN id SET DEFAULT nextval('minhascontas.chaves_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.clientes ALTER COLUMN id SET DEFAULT nextval('minhascontas.clientes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contadores ALTER COLUMN id SET DEFAULT nextval('minhascontas.contadores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contratos ALTER COLUMN id SET DEFAULT nextval('minhascontas.contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.empresas ALTER COLUMN id SET DEFAULT nextval('minhascontas.empresas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.evento_contratos ALTER COLUMN id SET DEFAULT nextval('minhascontas.evento_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.eventos ALTER COLUMN id SET DEFAULT nextval('minhascontas.eventos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.fatura_itens ALTER COLUMN id SET DEFAULT nextval('minhascontas.fatura_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.faturas ALTER COLUMN id SET DEFAULT nextval('minhascontas.faturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.forma_pagamentos ALTER COLUMN id SET DEFAULT nextval('minhascontas.forma_pagamentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.grupos ALTER COLUMN id SET DEFAULT nextval('minhascontas.grupos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.item_contratos ALTER COLUMN id SET DEFAULT nextval('minhascontas.item_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.notificacoes ALTER COLUMN id SET DEFAULT nextval('minhascontas.notificacoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.pessoas ALTER COLUMN id SET DEFAULT nextval('minhascontas.pessoas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.produtos ALTER COLUMN id SET DEFAULT nextval('minhascontas.produtos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_configs ALTER COLUMN id SET DEFAULT nextval('minhascontas.ticket_configs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_movimentos ALTER COLUMN id SET DEFAULT nextval('minhascontas.ticket_movimentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.tickets ALTER COLUMN id SET DEFAULT nextval('minhascontas.tickets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ajudas ALTER COLUMN id SET DEFAULT nextval('public.ajudas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.chaves ALTER COLUMN id SET DEFAULT nextval('public.chaves_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contadores ALTER COLUMN id SET DEFAULT nextval('public.contadores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contratos ALTER COLUMN id SET DEFAULT nextval('public.contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.empresas ALTER COLUMN id SET DEFAULT nextval('public.empresas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.evento_contratos ALTER COLUMN id SET DEFAULT nextval('public.evento_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.eventos ALTER COLUMN id SET DEFAULT nextval('public.eventos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.fatura_itens ALTER COLUMN id SET DEFAULT nextval('public.fatura_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.faturas ALTER COLUMN id SET DEFAULT nextval('public.faturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.forma_pagamentos ALTER COLUMN id SET DEFAULT nextval('public.forma_pagamentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.grupos ALTER COLUMN id SET DEFAULT nextval('public.grupos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.item_contratos ALTER COLUMN id SET DEFAULT nextval('public.item_contratos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.notificacoes ALTER COLUMN id SET DEFAULT nextval('public.notificacoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.pessoas ALTER COLUMN id SET DEFAULT nextval('public.pessoas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.produtos ALTER COLUMN id SET DEFAULT nextval('public.produtos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_configs ALTER COLUMN id SET DEFAULT nextval('public.ticket_configs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_movimentos ALTER COLUMN id SET DEFAULT nextval('public.ticket_movimentos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Data for Name: ajudas; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.ajudas (id, titulo, descricao, created_at, updated_at) FROM stdin;
\.
COPY faturamento.ajudas (id, titulo, descricao, created_at, updated_at) FROM '$$PATH$$/3331.dat';

--
-- Name: ajudas_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.ajudas_id_seq', 3, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY faturamento.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: chaves; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.chaves (id, data, password, created_at, updated_at) FROM stdin;
\.
COPY faturamento.chaves (id, data, password, created_at, updated_at) FROM '$$PATH$$/3333.dat';

--
-- Name: chaves_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.chaves_id_seq', 1, false);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, email, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token, notifica) FROM stdin;
\.
COPY faturamento.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, email, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token, notifica) FROM '$$PATH$$/3335.dat';

--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.clientes_id_seq', 1, false);


--
-- Data for Name: contadores; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM stdin;
\.
COPY faturamento.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM '$$PATH$$/3337.dat';

--
-- Name: contadores_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.contadores_id_seq', 1, false);


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM stdin;
\.
COPY faturamento.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM '$$PATH$$/3339.dat';

--
-- Name: contratos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.contratos_id_seq', 1, false);


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM stdin;
\.
COPY faturamento.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM '$$PATH$$/3341.dat';

--
-- Name: empresas_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.empresas_id_seq', 1, false);


--
-- Data for Name: evento_contratos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY faturamento.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3343.dat';

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.evento_contratos_id_seq', 1, false);


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM stdin;
\.
COPY faturamento.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM '$$PATH$$/3345.dat';

--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.eventos_id_seq', 1, false);


--
-- Data for Name: fatura_itens; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM stdin;
\.
COPY faturamento.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM '$$PATH$$/3347.dat';

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.fatura_itens_id_seq', 1, false);


--
-- Data for Name: faturas; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM stdin;
\.
COPY faturamento.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM '$$PATH$$/3349.dat';

--
-- Name: faturas_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.faturas_id_seq', 1, false);


--
-- Data for Name: forma_pagamentos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM stdin;
\.
COPY faturamento.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM '$$PATH$$/3351.dat';

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.forma_pagamentos_id_seq', 1, false);


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.grupos (id, descricao, created_at, updated_at) FROM stdin;
\.
COPY faturamento.grupos (id, descricao, created_at, updated_at) FROM '$$PATH$$/3353.dat';

--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.grupos_id_seq', 1, false);


--
-- Data for Name: item_contratos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM stdin;
\.
COPY faturamento.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM '$$PATH$$/3355.dat';

--
-- Name: item_contratos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.item_contratos_id_seq', 1, false);


--
-- Data for Name: notificacoes; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM stdin;
\.
COPY faturamento.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM '$$PATH$$/3357.dat';

--
-- Name: notificacoes_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.notificacoes_id_seq', 1, false);


--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado, notifica) FROM stdin;
\.
COPY faturamento.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado, notifica) FROM '$$PATH$$/3359.dat';

--
-- Name: pessoas_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.pessoas_id_seq', 2, true);


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM stdin;
\.
COPY faturamento.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM '$$PATH$$/3361.dat';

--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.produtos_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.schema_migrations (version) FROM stdin;
\.
COPY faturamento.schema_migrations (version) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: ticket_configs; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.ticket_configs (id, dias_resposta, created_at, updated_at) FROM stdin;
\.
COPY faturamento.ticket_configs (id, dias_resposta, created_at, updated_at) FROM '$$PATH$$/3363.dat';

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.ticket_configs_id_seq', 1, false);


--
-- Data for Name: ticket_movimentos; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY faturamento.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3365.dat';

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.ticket_movimentos_id_seq', 1, false);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: faturamento; Owner: faturamento
--

COPY faturamento.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM stdin;
\.
COPY faturamento.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM '$$PATH$$/3367.dat';

--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: faturamento; Owner: faturamento
--

SELECT pg_catalog.setval('faturamento.tickets_id_seq', 1, false);


--
-- Data for Name: ajudas; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.ajudas (id, titulo, descricao, created_at, updated_at) FROM stdin;
\.
COPY financeiro.ajudas (id, titulo, descricao, created_at, updated_at) FROM '$$PATH$$/3198.dat';

--
-- Name: ajudas_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.ajudas_id_seq', 2, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY financeiro.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3200.dat';

--
-- Data for Name: chaves; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.chaves (id, data, password, created_at, updated_at) FROM stdin;
\.
COPY financeiro.chaves (id, data, password, created_at, updated_at) FROM '$$PATH$$/3201.dat';

--
-- Name: chaves_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.chaves_id_seq', 1, true);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, email, bloqueado, token, notifica) FROM stdin;
\.
COPY financeiro.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, email, bloqueado, token, notifica) FROM '$$PATH$$/3309.dat';

--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.clientes_id_seq', 349, true);


--
-- Data for Name: contadores; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM stdin;
\.
COPY financeiro.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM '$$PATH$$/3203.dat';

--
-- Name: contadores_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.contadores_id_seq', 39, true);


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM stdin;
\.
COPY financeiro.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM '$$PATH$$/3205.dat';

--
-- Name: contratos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.contratos_id_seq', 1151, true);


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM stdin;
\.
COPY financeiro.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM '$$PATH$$/3207.dat';

--
-- Name: empresas_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.empresas_id_seq', 1, false);


--
-- Data for Name: evento_contratos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY financeiro.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3209.dat';

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.evento_contratos_id_seq', 1, false);


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM stdin;
\.
COPY financeiro.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM '$$PATH$$/3211.dat';

--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.eventos_id_seq', 5339, true);


--
-- Data for Name: fatura_itens; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM stdin;
\.
COPY financeiro.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM '$$PATH$$/3213.dat';

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.fatura_itens_id_seq', 543, true);


--
-- Data for Name: faturas; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM stdin;
\.
COPY financeiro.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM '$$PATH$$/3215.dat';

--
-- Name: faturas_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.faturas_id_seq', 20013, true);


--
-- Data for Name: forma_pagamentos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM stdin;
\.
COPY financeiro.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM '$$PATH$$/3217.dat';

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.forma_pagamentos_id_seq', 15, true);


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.grupos (id, descricao, created_at, updated_at) FROM stdin;
\.
COPY financeiro.grupos (id, descricao, created_at, updated_at) FROM '$$PATH$$/3219.dat';

--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.grupos_id_seq', 6, true);


--
-- Data for Name: item_contratos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM stdin;
\.
COPY financeiro.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM '$$PATH$$/3221.dat';

--
-- Name: item_contratos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.item_contratos_id_seq', 1, false);


--
-- Data for Name: notificacoes; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM stdin;
\.
COPY financeiro.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM '$$PATH$$/3223.dat';

--
-- Name: notificacoes_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.notificacoes_id_seq', 1, false);


--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado, notifica) FROM stdin;
\.
COPY financeiro.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado, notifica) FROM '$$PATH$$/3225.dat';

--
-- Name: pessoas_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.pessoas_id_seq', 350, true);


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM stdin;
\.
COPY financeiro.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM '$$PATH$$/3227.dat';

--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.produtos_id_seq', 60, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.schema_migrations (version) FROM stdin;
\.
COPY financeiro.schema_migrations (version) FROM '$$PATH$$/3229.dat';

--
-- Data for Name: ticket_configs; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.ticket_configs (id, dias_resposta, created_at, updated_at) FROM stdin;
\.
COPY financeiro.ticket_configs (id, dias_resposta, created_at, updated_at) FROM '$$PATH$$/3323.dat';

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.ticket_configs_id_seq', 1, true);


--
-- Data for Name: ticket_movimentos; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY financeiro.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3321.dat';

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.ticket_movimentos_id_seq', 20, true);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: financeiro; Owner: faturamento
--

COPY financeiro.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM stdin;
\.
COPY financeiro.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM '$$PATH$$/3319.dat';

--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: financeiro; Owner: faturamento
--

SELECT pg_catalog.setval('financeiro.tickets_id_seq', 7, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY kallario.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3230.dat';

--
-- Data for Name: contratos; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.contratos (id, pessoa_id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at) FROM stdin;
\.
COPY kallario.contratos (id, pessoa_id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at) FROM '$$PATH$$/3231.dat';

--
-- Name: contratos_id_seq; Type: SEQUENCE SET; Schema: kallario; Owner: faturamento
--

SELECT pg_catalog.setval('kallario.contratos_id_seq', 1, false);


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM stdin;
\.
COPY kallario.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM '$$PATH$$/3233.dat';

--
-- Name: empresas_id_seq; Type: SEQUENCE SET; Schema: kallario; Owner: faturamento
--

SELECT pg_catalog.setval('kallario.empresas_id_seq', 1, false);


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.eventos (id, fatura_id, pessoa_id, data, valor, forma_pagamento, tipo_evento, created_at, updated_at, observacao) FROM stdin;
\.
COPY kallario.eventos (id, fatura_id, pessoa_id, data, valor, forma_pagamento, tipo_evento, created_at, updated_at, observacao) FROM '$$PATH$$/3235.dat';

--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: kallario; Owner: faturamento
--

SELECT pg_catalog.setval('kallario.eventos_id_seq', 1, false);


--
-- Data for Name: faturas; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at) FROM stdin;
\.
COPY kallario.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at) FROM '$$PATH$$/3237.dat';

--
-- Name: faturas_id_seq; Type: SEQUENCE SET; Schema: kallario; Owner: faturamento
--

SELECT pg_catalog.setval('kallario.faturas_id_seq', 1, false);


--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip) FROM stdin;
\.
COPY kallario.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip) FROM '$$PATH$$/3239.dat';

--
-- Name: pessoas_id_seq; Type: SEQUENCE SET; Schema: kallario; Owner: faturamento
--

SELECT pg_catalog.setval('kallario.pessoas_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: kallario; Owner: faturamento
--

COPY kallario.schema_migrations (version) FROM stdin;
\.
COPY kallario.schema_migrations (version) FROM '$$PATH$$/3241.dat';

--
-- Data for Name: ajudas; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.ajudas (id, titulo, descricao, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.ajudas (id, titulo, descricao, created_at, updated_at) FROM '$$PATH$$/3242.dat';

--
-- Name: ajudas_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.ajudas_id_seq', 1, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3244.dat';

--
-- Data for Name: chaves; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.chaves (id, data, password, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.chaves (id, data, password, created_at, updated_at) FROM '$$PATH$$/3245.dat';

--
-- Name: chaves_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.chaves_id_seq', 1, true);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token) FROM stdin;
\.
COPY minhascontas.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token) FROM '$$PATH$$/3311.dat';

--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.clientes_id_seq', 1, false);


--
-- Data for Name: contadores; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM '$$PATH$$/3247.dat';

--
-- Name: contadores_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.contadores_id_seq', 1, false);


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM stdin;
\.
COPY minhascontas.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM '$$PATH$$/3249.dat';

--
-- Name: contratos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.contratos_id_seq', 2, true);


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM stdin;
\.
COPY minhascontas.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM '$$PATH$$/3251.dat';

--
-- Name: empresas_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.empresas_id_seq', 1, false);


--
-- Data for Name: evento_contratos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3253.dat';

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.evento_contratos_id_seq', 1, false);


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM stdin;
\.
COPY minhascontas.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM '$$PATH$$/3255.dat';

--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.eventos_id_seq', 11, true);


--
-- Data for Name: fatura_itens; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM stdin;
\.
COPY minhascontas.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM '$$PATH$$/3257.dat';

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.fatura_itens_id_seq', 13, true);


--
-- Data for Name: faturas; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM stdin;
\.
COPY minhascontas.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM '$$PATH$$/3259.dat';

--
-- Name: faturas_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.faturas_id_seq', 24, true);


--
-- Data for Name: forma_pagamentos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM stdin;
\.
COPY minhascontas.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM '$$PATH$$/3261.dat';

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.forma_pagamentos_id_seq', 14, true);


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.grupos (id, descricao, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.grupos (id, descricao, created_at, updated_at) FROM '$$PATH$$/3263.dat';

--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.grupos_id_seq', 2, true);


--
-- Data for Name: item_contratos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM '$$PATH$$/3265.dat';

--
-- Name: item_contratos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.item_contratos_id_seq', 1, false);


--
-- Data for Name: notificacoes; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM '$$PATH$$/3267.dat';

--
-- Name: notificacoes_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.notificacoes_id_seq', 1, false);


--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado) FROM stdin;
\.
COPY minhascontas.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado) FROM '$$PATH$$/3269.dat';

--
-- Name: pessoas_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.pessoas_id_seq', 4, true);


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM stdin;
\.
COPY minhascontas.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM '$$PATH$$/3271.dat';

--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.produtos_id_seq', 1, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.schema_migrations (version) FROM stdin;
\.
COPY minhascontas.schema_migrations (version) FROM '$$PATH$$/3273.dat';

--
-- Data for Name: ticket_configs; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.ticket_configs (id, dias_resposta, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.ticket_configs (id, dias_resposta, created_at, updated_at) FROM '$$PATH$$/3329.dat';

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.ticket_configs_id_seq', 1, false);


--
-- Data for Name: ticket_movimentos; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3327.dat';

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.ticket_movimentos_id_seq', 1, false);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: minhascontas; Owner: faturamento
--

COPY minhascontas.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM stdin;
\.
COPY minhascontas.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM '$$PATH$$/3325.dat';

--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: minhascontas; Owner: faturamento
--

SELECT pg_catalog.setval('minhascontas.tickets_id_seq', 1, false);


--
-- Data for Name: ajudas; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.ajudas (id, titulo, descricao, created_at, updated_at) FROM stdin;
\.
COPY public.ajudas (id, titulo, descricao, created_at, updated_at) FROM '$$PATH$$/3274.dat';

--
-- Name: ajudas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.ajudas_id_seq', 1, true);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: chaves; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.chaves (id, data, password, created_at, updated_at) FROM stdin;
\.
COPY public.chaves (id, data, password, created_at, updated_at) FROM '$$PATH$$/3277.dat';

--
-- Name: chaves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.chaves_id_seq', 1, true);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token) FROM stdin;
\.
COPY public.clientes (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, pessoa_id, grupo, cadastrado_em, ativo, created_at, updated_at, bloqueado, token) FROM '$$PATH$$/3307.dat';

--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.clientes_id_seq', 1, false);


--
-- Data for Name: contadores; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM stdin;
\.
COPY public.contadores (id, nome_escritorio, nome_contador, crc, municipio, uf, telefone, celular, whatsapp, email, created_at, updated_at) FROM '$$PATH$$/3279.dat';

--
-- Name: contadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.contadores_id_seq', 1, false);


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM stdin;
\.
COPY public.contratos (id, data_inicio_contrato, data_termino_contrato, tipo_contrato, descricao, dia_vencimento, valor_cobrado, multa, juros, tipo_juros, observacoes, created_at, updated_at, forma_pagamento_id, cliente_id, url_slip_pdf) FROM '$$PATH$$/3281.dat';

--
-- Name: contratos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.contratos_id_seq', 1, false);


--
-- Data for Name: empresas; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM stdin;
\.
COPY public.empresas (id, nome, cnpj, telefone, endereco, bairro, cidade, cep, subdomain, created_at, updated_at, email) FROM '$$PATH$$/3283.dat';

--
-- Name: empresas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.empresas_id_seq', 6, true);


--
-- Data for Name: evento_contratos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY public.evento_contratos (id, contrato_id, valor_contrato, data_inicio_evento, periodo, motivo, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3285.dat';

--
-- Name: evento_contratos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.evento_contratos_id_seq', 1, false);


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM stdin;
\.
COPY public.eventos (id, fatura_id, pessoa_id, data, valor, tipo_evento, created_at, updated_at, observacao, forma_pagamento_id, desconto) FROM '$$PATH$$/3287.dat';

--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.eventos_id_seq', 1, false);


--
-- Data for Name: fatura_itens; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM stdin;
\.
COPY public.fatura_itens (id, fatura_id, produto_id, quantidade, preco_unitario, created_at, updated_at, data, pessoa_id, parcelado) FROM '$$PATH$$/3289.dat';

--
-- Name: fatura_itens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.fatura_itens_id_seq', 1, false);


--
-- Data for Name: faturas; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM stdin;
\.
COPY public.faturas (id, contrato_id, vencimento, valor_fatura, situacao, observacoes, created_at, updated_at, acrescimos, descontos, total_pago, transaction_id, url_slip_pdf, due_date, status, order_id) FROM '$$PATH$$/3291.dat';

--
-- Name: faturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.faturas_id_seq', 1, false);


--
-- Data for Name: forma_pagamentos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM stdin;
\.
COPY public.forma_pagamentos (id, descricao, created_at, updated_at, instrucoes, emite_boleto, dia_emissao_boletos, type_bank_slip, fixed_description, late_payment_fine, per_day_interest, early_payment_discounts_days, early_payment_discounts_cents, open_after_day_due) FROM '$$PATH$$/3293.dat';

--
-- Name: forma_pagamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.forma_pagamentos_id_seq', 14, true);


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.grupos (id, descricao, created_at, updated_at) FROM stdin;
\.
COPY public.grupos (id, descricao, created_at, updated_at) FROM '$$PATH$$/3295.dat';

--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.grupos_id_seq', 1, false);


--
-- Data for Name: item_contratos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM stdin;
\.
COPY public.item_contratos (id, contrato_id, produto_id, quantidade, preco_unitario, created_at, updated_at) FROM '$$PATH$$/3297.dat';

--
-- Name: item_contratos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.item_contratos_id_seq', 1, false);


--
-- Data for Name: notificacoes; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM stdin;
\.
COPY public.notificacoes (id, recipiente_id, autor_id, lido_em, assunto, notificacao_id, notificacao_tipo, created_at, updated_at) FROM '$$PATH$$/3299.dat';

--
-- Name: notificacoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.notificacoes_id_seq', 1, false);


--
-- Data for Name: pessoas; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado) FROM stdin;
\.
COPY public.pessoas (id, nome, tipo_pessoa, numero_cadastro_pessoa, logradouro, numero, complemento, bairro, cidade, estado, cep, telefone, celular, grupo, cadastrado_em, ativo, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, latitude, longitude, nome_fantasia, contato, inscricao_estadual, inscricao_municipal, whatsapp, contador_id, bloqueado) FROM '$$PATH$$/3301.dat';

--
-- Name: pessoas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.pessoas_id_seq', 2, true);


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM stdin;
\.
COPY public.produtos (id, grupo_id, descricao, unidade, marca, modelo, preco_custo, preco_venda, estoque_inicial, estoque_entrada, estoque_saida, ativo, created_at, updated_at, controla_estoque) FROM '$$PATH$$/3303.dat';

--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.produtos_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3305.dat';

--
-- Data for Name: ticket_configs; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.ticket_configs (id, dias_resposta, created_at, updated_at) FROM stdin;
\.
COPY public.ticket_configs (id, dias_resposta, created_at, updated_at) FROM '$$PATH$$/3317.dat';

--
-- Name: ticket_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.ticket_configs_id_seq', 1, false);


--
-- Data for Name: ticket_movimentos; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM stdin;
\.
COPY public.ticket_movimentos (id, ticket_id, data_movimento, tipo_movimento, observacoes, pessoa_id, created_at, updated_at) FROM '$$PATH$$/3315.dat';

--
-- Name: ticket_movimentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.ticket_movimentos_id_seq', 1, false);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: faturamento
--

COPY public.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM stdin;
\.
COPY public.tickets (id, cliente_id, data_abertura, assunto, solicitacao_texto, status, created_at, updated_at) FROM '$$PATH$$/3313.dat';

--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faturamento
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: ajudas_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ajudas
    ADD CONSTRAINT ajudas_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: chaves_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.chaves
    ADD CONSTRAINT chaves_pkey PRIMARY KEY (id);


--
-- Name: clientes_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: contadores_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contadores
    ADD CONSTRAINT contadores_pkey PRIMARY KEY (id);


--
-- Name: contratos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: empresas_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: evento_contratos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.evento_contratos
    ADD CONSTRAINT evento_contratos_pkey PRIMARY KEY (id);


--
-- Name: eventos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: fatura_itens_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.fatura_itens
    ADD CONSTRAINT fatura_itens_pkey PRIMARY KEY (id);


--
-- Name: faturas_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.faturas
    ADD CONSTRAINT faturas_pkey PRIMARY KEY (id);


--
-- Name: forma_pagamentos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.forma_pagamentos
    ADD CONSTRAINT forma_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: grupos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: item_contratos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.item_contratos
    ADD CONSTRAINT item_contratos_pkey PRIMARY KEY (id);


--
-- Name: notificacoes_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.notificacoes
    ADD CONSTRAINT notificacoes_pkey PRIMARY KEY (id);


--
-- Name: pessoas_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.pessoas
    ADD CONSTRAINT pessoas_pkey PRIMARY KEY (id);


--
-- Name: produtos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ticket_configs_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_configs
    ADD CONSTRAINT ticket_configs_pkey PRIMARY KEY (id);


--
-- Name: ticket_movimentos_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_movimentos
    ADD CONSTRAINT ticket_movimentos_pkey PRIMARY KEY (id);


--
-- Name: tickets_pkey; Type: CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: ajudas_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ajudas
    ADD CONSTRAINT ajudas_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: chaves_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.chaves
    ADD CONSTRAINT chaves_pkey PRIMARY KEY (id);


--
-- Name: clientes_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: contadores_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contadores
    ADD CONSTRAINT contadores_pkey PRIMARY KEY (id);


--
-- Name: contratos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: empresas_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: evento_contratos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.evento_contratos
    ADD CONSTRAINT evento_contratos_pkey PRIMARY KEY (id);


--
-- Name: eventos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: fatura_itens_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.fatura_itens
    ADD CONSTRAINT fatura_itens_pkey PRIMARY KEY (id);


--
-- Name: faturas_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.faturas
    ADD CONSTRAINT faturas_pkey PRIMARY KEY (id);


--
-- Name: forma_pagamentos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.forma_pagamentos
    ADD CONSTRAINT forma_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: grupos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: item_contratos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.item_contratos
    ADD CONSTRAINT item_contratos_pkey PRIMARY KEY (id);


--
-- Name: notificacoes_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.notificacoes
    ADD CONSTRAINT notificacoes_pkey PRIMARY KEY (id);


--
-- Name: pessoas_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.pessoas
    ADD CONSTRAINT pessoas_pkey PRIMARY KEY (id);


--
-- Name: produtos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ticket_configs_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_configs
    ADD CONSTRAINT ticket_configs_pkey PRIMARY KEY (id);


--
-- Name: ticket_movimentos_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_movimentos
    ADD CONSTRAINT ticket_movimentos_pkey PRIMARY KEY (id);


--
-- Name: tickets_pkey; Type: CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: contratos_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: empresas_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: eventos_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: faturas_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.faturas
    ADD CONSTRAINT faturas_pkey PRIMARY KEY (id);


--
-- Name: pessoas_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.pessoas
    ADD CONSTRAINT pessoas_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ajudas_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ajudas
    ADD CONSTRAINT ajudas_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: chaves_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.chaves
    ADD CONSTRAINT chaves_pkey PRIMARY KEY (id);


--
-- Name: clientes_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: contadores_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contadores
    ADD CONSTRAINT contadores_pkey PRIMARY KEY (id);


--
-- Name: contratos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: empresas_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: evento_contratos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.evento_contratos
    ADD CONSTRAINT evento_contratos_pkey PRIMARY KEY (id);


--
-- Name: eventos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: fatura_itens_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.fatura_itens
    ADD CONSTRAINT fatura_itens_pkey PRIMARY KEY (id);


--
-- Name: faturas_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.faturas
    ADD CONSTRAINT faturas_pkey PRIMARY KEY (id);


--
-- Name: forma_pagamentos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.forma_pagamentos
    ADD CONSTRAINT forma_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: grupos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: item_contratos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.item_contratos
    ADD CONSTRAINT item_contratos_pkey PRIMARY KEY (id);


--
-- Name: notificacoes_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.notificacoes
    ADD CONSTRAINT notificacoes_pkey PRIMARY KEY (id);


--
-- Name: pessoas_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.pessoas
    ADD CONSTRAINT pessoas_pkey PRIMARY KEY (id);


--
-- Name: produtos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ticket_configs_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_configs
    ADD CONSTRAINT ticket_configs_pkey PRIMARY KEY (id);


--
-- Name: ticket_movimentos_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_movimentos
    ADD CONSTRAINT ticket_movimentos_pkey PRIMARY KEY (id);


--
-- Name: tickets_pkey; Type: CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: ajudas_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ajudas
    ADD CONSTRAINT ajudas_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: chaves_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.chaves
    ADD CONSTRAINT chaves_pkey PRIMARY KEY (id);


--
-- Name: clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: contadores_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contadores
    ADD CONSTRAINT contadores_pkey PRIMARY KEY (id);


--
-- Name: contratos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: empresas_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (id);


--
-- Name: evento_contratos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.evento_contratos
    ADD CONSTRAINT evento_contratos_pkey PRIMARY KEY (id);


--
-- Name: eventos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: fatura_itens_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.fatura_itens
    ADD CONSTRAINT fatura_itens_pkey PRIMARY KEY (id);


--
-- Name: faturas_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.faturas
    ADD CONSTRAINT faturas_pkey PRIMARY KEY (id);


--
-- Name: forma_pagamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.forma_pagamentos
    ADD CONSTRAINT forma_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: item_contratos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.item_contratos
    ADD CONSTRAINT item_contratos_pkey PRIMARY KEY (id);


--
-- Name: notificacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.notificacoes
    ADD CONSTRAINT notificacoes_pkey PRIMARY KEY (id);


--
-- Name: pessoas_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.pessoas
    ADD CONSTRAINT pessoas_pkey PRIMARY KEY (id);


--
-- Name: produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ticket_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_configs
    ADD CONSTRAINT ticket_configs_pkey PRIMARY KEY (id);


--
-- Name: ticket_movimentos_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_movimentos
    ADD CONSTRAINT ticket_movimentos_pkey PRIMARY KEY (id);


--
-- Name: tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: index_clientes_on_contador_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_clientes_on_contador_id ON faturamento.clientes USING btree (contador_id);


--
-- Name: index_contratos_on_cliente_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_contratos_on_cliente_id ON faturamento.contratos USING btree (cliente_id);


--
-- Name: index_contratos_on_forma_pagamento_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_contratos_on_forma_pagamento_id ON faturamento.contratos USING btree (forma_pagamento_id);


--
-- Name: index_evento_contratos_on_contrato_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_contrato_id ON faturamento.evento_contratos USING btree (contrato_id);


--
-- Name: index_evento_contratos_on_pessoa_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_pessoa_id ON faturamento.evento_contratos USING btree (pessoa_id);


--
-- Name: index_eventos_on_fatura_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_eventos_on_fatura_id ON faturamento.eventos USING btree (fatura_id);


--
-- Name: index_eventos_on_forma_pagamento_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_eventos_on_forma_pagamento_id ON faturamento.eventos USING btree (forma_pagamento_id);


--
-- Name: index_eventos_on_pessoa_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_eventos_on_pessoa_id ON faturamento.eventos USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_fatura_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_fatura_id ON faturamento.fatura_itens USING btree (fatura_id);


--
-- Name: index_fatura_itens_on_pessoa_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_pessoa_id ON faturamento.fatura_itens USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_produto_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_produto_id ON faturamento.fatura_itens USING btree (produto_id);


--
-- Name: index_faturas_on_contrato_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_faturas_on_contrato_id ON faturamento.faturas USING btree (contrato_id);


--
-- Name: index_item_contratos_on_contrato_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_contrato_id ON faturamento.item_contratos USING btree (contrato_id);


--
-- Name: index_item_contratos_on_produto_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_produto_id ON faturamento.item_contratos USING btree (produto_id);


--
-- Name: index_pessoas_on_contador_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_pessoas_on_contador_id ON faturamento.pessoas USING btree (contador_id);


--
-- Name: index_pessoas_on_email; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_email ON faturamento.pessoas USING btree (email);


--
-- Name: index_pessoas_on_reset_password_token; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_reset_password_token ON faturamento.pessoas USING btree (reset_password_token);


--
-- Name: index_produtos_on_grupo_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_produtos_on_grupo_id ON faturamento.produtos USING btree (grupo_id);


--
-- Name: index_ticket_movimentos_on_pessoa_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_pessoa_id ON faturamento.ticket_movimentos USING btree (pessoa_id);


--
-- Name: index_ticket_movimentos_on_ticket_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_ticket_id ON faturamento.ticket_movimentos USING btree (ticket_id);


--
-- Name: index_tickets_on_cliente_id; Type: INDEX; Schema: faturamento; Owner: faturamento
--

CREATE INDEX index_tickets_on_cliente_id ON faturamento.tickets USING btree (cliente_id);


--
-- Name: index_clientes_on_contador_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_clientes_on_contador_id ON financeiro.clientes USING btree (contador_id);


--
-- Name: index_clientes_on_pessoa_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_clientes_on_pessoa_id ON financeiro.clientes USING btree (pessoa_id);


--
-- Name: index_contratos_on_cliente_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_contratos_on_cliente_id ON financeiro.contratos USING btree (cliente_id);


--
-- Name: index_contratos_on_forma_pagamento_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_contratos_on_forma_pagamento_id ON financeiro.contratos USING btree (forma_pagamento_id);


--
-- Name: index_evento_contratos_on_contrato_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_contrato_id ON financeiro.evento_contratos USING btree (contrato_id);


--
-- Name: index_evento_contratos_on_pessoa_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_pessoa_id ON financeiro.evento_contratos USING btree (pessoa_id);


--
-- Name: index_eventos_on_fatura_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_eventos_on_fatura_id ON financeiro.eventos USING btree (fatura_id);


--
-- Name: index_eventos_on_forma_pagamento_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_eventos_on_forma_pagamento_id ON financeiro.eventos USING btree (forma_pagamento_id);


--
-- Name: index_eventos_on_pessoa_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_eventos_on_pessoa_id ON financeiro.eventos USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_fatura_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_fatura_id ON financeiro.fatura_itens USING btree (fatura_id);


--
-- Name: index_fatura_itens_on_pessoa_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_pessoa_id ON financeiro.fatura_itens USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_produto_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_produto_id ON financeiro.fatura_itens USING btree (produto_id);


--
-- Name: index_faturas_on_contrato_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_faturas_on_contrato_id ON financeiro.faturas USING btree (contrato_id);


--
-- Name: index_item_contratos_on_contrato_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_contrato_id ON financeiro.item_contratos USING btree (contrato_id);


--
-- Name: index_item_contratos_on_produto_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_produto_id ON financeiro.item_contratos USING btree (produto_id);


--
-- Name: index_pessoas_on_contador_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_pessoas_on_contador_id ON financeiro.pessoas USING btree (contador_id);


--
-- Name: index_pessoas_on_email; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_email ON financeiro.pessoas USING btree (email);


--
-- Name: index_pessoas_on_reset_password_token; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_reset_password_token ON financeiro.pessoas USING btree (reset_password_token);


--
-- Name: index_produtos_on_grupo_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_produtos_on_grupo_id ON financeiro.produtos USING btree (grupo_id);


--
-- Name: index_ticket_movimentos_on_pessoa_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_pessoa_id ON financeiro.ticket_movimentos USING btree (pessoa_id);


--
-- Name: index_ticket_movimentos_on_ticket_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_ticket_id ON financeiro.ticket_movimentos USING btree (ticket_id);


--
-- Name: index_tickets_on_cliente_id; Type: INDEX; Schema: financeiro; Owner: faturamento
--

CREATE INDEX index_tickets_on_cliente_id ON financeiro.tickets USING btree (cliente_id);


--
-- Name: index_contratos_on_pessoa_id; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE INDEX index_contratos_on_pessoa_id ON kallario.contratos USING btree (pessoa_id);


--
-- Name: index_eventos_on_fatura_id; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE INDEX index_eventos_on_fatura_id ON kallario.eventos USING btree (fatura_id);


--
-- Name: index_eventos_on_pessoa_id; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE INDEX index_eventos_on_pessoa_id ON kallario.eventos USING btree (pessoa_id);


--
-- Name: index_faturas_on_contrato_id; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE INDEX index_faturas_on_contrato_id ON kallario.faturas USING btree (contrato_id);


--
-- Name: index_pessoas_on_email; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_email ON kallario.pessoas USING btree (email);


--
-- Name: index_pessoas_on_reset_password_token; Type: INDEX; Schema: kallario; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_reset_password_token ON kallario.pessoas USING btree (reset_password_token);


--
-- Name: index_clientes_on_contador_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_clientes_on_contador_id ON minhascontas.clientes USING btree (contador_id);


--
-- Name: index_clientes_on_pessoa_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_clientes_on_pessoa_id ON minhascontas.clientes USING btree (pessoa_id);


--
-- Name: index_contratos_on_cliente_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_contratos_on_cliente_id ON minhascontas.contratos USING btree (cliente_id);


--
-- Name: index_contratos_on_forma_pagamento_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_contratos_on_forma_pagamento_id ON minhascontas.contratos USING btree (forma_pagamento_id);


--
-- Name: index_evento_contratos_on_contrato_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_contrato_id ON minhascontas.evento_contratos USING btree (contrato_id);


--
-- Name: index_evento_contratos_on_pessoa_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_pessoa_id ON minhascontas.evento_contratos USING btree (pessoa_id);


--
-- Name: index_eventos_on_fatura_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_eventos_on_fatura_id ON minhascontas.eventos USING btree (fatura_id);


--
-- Name: index_eventos_on_forma_pagamento_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_eventos_on_forma_pagamento_id ON minhascontas.eventos USING btree (forma_pagamento_id);


--
-- Name: index_eventos_on_pessoa_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_eventos_on_pessoa_id ON minhascontas.eventos USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_fatura_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_fatura_id ON minhascontas.fatura_itens USING btree (fatura_id);


--
-- Name: index_fatura_itens_on_pessoa_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_pessoa_id ON minhascontas.fatura_itens USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_produto_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_produto_id ON minhascontas.fatura_itens USING btree (produto_id);


--
-- Name: index_faturas_on_contrato_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_faturas_on_contrato_id ON minhascontas.faturas USING btree (contrato_id);


--
-- Name: index_item_contratos_on_contrato_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_contrato_id ON minhascontas.item_contratos USING btree (contrato_id);


--
-- Name: index_item_contratos_on_produto_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_produto_id ON minhascontas.item_contratos USING btree (produto_id);


--
-- Name: index_pessoas_on_contador_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_pessoas_on_contador_id ON minhascontas.pessoas USING btree (contador_id);


--
-- Name: index_pessoas_on_email; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_email ON minhascontas.pessoas USING btree (email);


--
-- Name: index_pessoas_on_reset_password_token; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_reset_password_token ON minhascontas.pessoas USING btree (reset_password_token);


--
-- Name: index_produtos_on_grupo_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_produtos_on_grupo_id ON minhascontas.produtos USING btree (grupo_id);


--
-- Name: index_ticket_movimentos_on_pessoa_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_pessoa_id ON minhascontas.ticket_movimentos USING btree (pessoa_id);


--
-- Name: index_ticket_movimentos_on_ticket_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_ticket_id ON minhascontas.ticket_movimentos USING btree (ticket_id);


--
-- Name: index_tickets_on_cliente_id; Type: INDEX; Schema: minhascontas; Owner: faturamento
--

CREATE INDEX index_tickets_on_cliente_id ON minhascontas.tickets USING btree (cliente_id);


--
-- Name: index_clientes_on_contador_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_clientes_on_contador_id ON public.clientes USING btree (contador_id);


--
-- Name: index_clientes_on_pessoa_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_clientes_on_pessoa_id ON public.clientes USING btree (pessoa_id);


--
-- Name: index_contratos_on_cliente_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_contratos_on_cliente_id ON public.contratos USING btree (cliente_id);


--
-- Name: index_contratos_on_forma_pagamento_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_contratos_on_forma_pagamento_id ON public.contratos USING btree (forma_pagamento_id);


--
-- Name: index_evento_contratos_on_contrato_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_contrato_id ON public.evento_contratos USING btree (contrato_id);


--
-- Name: index_evento_contratos_on_pessoa_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_evento_contratos_on_pessoa_id ON public.evento_contratos USING btree (pessoa_id);


--
-- Name: index_eventos_on_fatura_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_eventos_on_fatura_id ON public.eventos USING btree (fatura_id);


--
-- Name: index_eventos_on_forma_pagamento_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_eventos_on_forma_pagamento_id ON public.eventos USING btree (forma_pagamento_id);


--
-- Name: index_eventos_on_pessoa_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_eventos_on_pessoa_id ON public.eventos USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_fatura_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_fatura_id ON public.fatura_itens USING btree (fatura_id);


--
-- Name: index_fatura_itens_on_pessoa_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_pessoa_id ON public.fatura_itens USING btree (pessoa_id);


--
-- Name: index_fatura_itens_on_produto_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_fatura_itens_on_produto_id ON public.fatura_itens USING btree (produto_id);


--
-- Name: index_faturas_on_contrato_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_faturas_on_contrato_id ON public.faturas USING btree (contrato_id);


--
-- Name: index_item_contratos_on_contrato_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_contrato_id ON public.item_contratos USING btree (contrato_id);


--
-- Name: index_item_contratos_on_produto_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_item_contratos_on_produto_id ON public.item_contratos USING btree (produto_id);


--
-- Name: index_pessoas_on_contador_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_pessoas_on_contador_id ON public.pessoas USING btree (contador_id);


--
-- Name: index_pessoas_on_email; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_email ON public.pessoas USING btree (email);


--
-- Name: index_pessoas_on_reset_password_token; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE UNIQUE INDEX index_pessoas_on_reset_password_token ON public.pessoas USING btree (reset_password_token);


--
-- Name: index_produtos_on_grupo_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_produtos_on_grupo_id ON public.produtos USING btree (grupo_id);


--
-- Name: index_ticket_movimentos_on_pessoa_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_pessoa_id ON public.ticket_movimentos USING btree (pessoa_id);


--
-- Name: index_ticket_movimentos_on_ticket_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_ticket_movimentos_on_ticket_id ON public.ticket_movimentos USING btree (ticket_id);


--
-- Name: index_tickets_on_cliente_id; Type: INDEX; Schema: public; Owner: faturamento
--

CREATE INDEX index_tickets_on_cliente_id ON public.tickets USING btree (cliente_id);


--
-- Name: fk_rails_1345469dfd; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.eventos
    ADD CONSTRAINT fk_rails_1345469dfd FOREIGN KEY (fatura_id) REFERENCES faturamento.faturas(id);


--
-- Name: fk_rails_14ff4bcf84; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.item_contratos
    ADD CONSTRAINT fk_rails_14ff4bcf84 FOREIGN KEY (contrato_id) REFERENCES faturamento.contratos(id);


--
-- Name: fk_rails_20838c8bc1; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.fatura_itens
    ADD CONSTRAINT fk_rails_20838c8bc1 FOREIGN KEY (fatura_id) REFERENCES faturamento.faturas(id);


--
-- Name: fk_rails_29a7c42f1c; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_movimentos
    ADD CONSTRAINT fk_rails_29a7c42f1c FOREIGN KEY (pessoa_id) REFERENCES faturamento.pessoas(id);


--
-- Name: fk_rails_2c0070d11e; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.tickets
    ADD CONSTRAINT fk_rails_2c0070d11e FOREIGN KEY (cliente_id) REFERENCES faturamento.clientes(id);


--
-- Name: fk_rails_36203af0ac; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.evento_contratos
    ADD CONSTRAINT fk_rails_36203af0ac FOREIGN KEY (pessoa_id) REFERENCES faturamento.pessoas(id);


--
-- Name: fk_rails_41b699d639; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.fatura_itens
    ADD CONSTRAINT fk_rails_41b699d639 FOREIGN KEY (pessoa_id) REFERENCES faturamento.pessoas(id);


--
-- Name: fk_rails_4b12b84b0d; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contratos
    ADD CONSTRAINT fk_rails_4b12b84b0d FOREIGN KEY (forma_pagamento_id) REFERENCES faturamento.forma_pagamentos(id);


--
-- Name: fk_rails_5720d03496; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.item_contratos
    ADD CONSTRAINT fk_rails_5720d03496 FOREIGN KEY (produto_id) REFERENCES faturamento.produtos(id);


--
-- Name: fk_rails_590c9073f0; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.produtos
    ADD CONSTRAINT fk_rails_590c9073f0 FOREIGN KEY (grupo_id) REFERENCES faturamento.grupos(id);


--
-- Name: fk_rails_6339760cdb; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.fatura_itens
    ADD CONSTRAINT fk_rails_6339760cdb FOREIGN KEY (produto_id) REFERENCES faturamento.produtos(id);


--
-- Name: fk_rails_7118cf7082; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.contratos
    ADD CONSTRAINT fk_rails_7118cf7082 FOREIGN KEY (cliente_id) REFERENCES faturamento.clientes(id);


--
-- Name: fk_rails_7819d066a4; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.clientes
    ADD CONSTRAINT fk_rails_7819d066a4 FOREIGN KEY (contador_id) REFERENCES faturamento.contadores(id);


--
-- Name: fk_rails_81b663bea4; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.pessoas
    ADD CONSTRAINT fk_rails_81b663bea4 FOREIGN KEY (contador_id) REFERENCES faturamento.contadores(id);


--
-- Name: fk_rails_94e3092784; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.eventos
    ADD CONSTRAINT fk_rails_94e3092784 FOREIGN KEY (forma_pagamento_id) REFERENCES faturamento.forma_pagamentos(id);


--
-- Name: fk_rails_a36a1e5090; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.faturas
    ADD CONSTRAINT fk_rails_a36a1e5090 FOREIGN KEY (contrato_id) REFERENCES faturamento.contratos(id);


--
-- Name: fk_rails_dba027c891; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.ticket_movimentos
    ADD CONSTRAINT fk_rails_dba027c891 FOREIGN KEY (ticket_id) REFERENCES faturamento.tickets(id);


--
-- Name: fk_rails_f2b9d888e2; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.eventos
    ADD CONSTRAINT fk_rails_f2b9d888e2 FOREIGN KEY (pessoa_id) REFERENCES faturamento.pessoas(id);


--
-- Name: fk_rails_f49398363f; Type: FK CONSTRAINT; Schema: faturamento; Owner: faturamento
--

ALTER TABLE ONLY faturamento.evento_contratos
    ADD CONSTRAINT fk_rails_f49398363f FOREIGN KEY (contrato_id) REFERENCES faturamento.contratos(id);


--
-- Name: fk_rails_1345469dfd; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.eventos
    ADD CONSTRAINT fk_rails_1345469dfd FOREIGN KEY (fatura_id) REFERENCES financeiro.faturas(id);


--
-- Name: fk_rails_14ff4bcf84; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.item_contratos
    ADD CONSTRAINT fk_rails_14ff4bcf84 FOREIGN KEY (contrato_id) REFERENCES financeiro.contratos(id);


--
-- Name: fk_rails_20838c8bc1; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.fatura_itens
    ADD CONSTRAINT fk_rails_20838c8bc1 FOREIGN KEY (fatura_id) REFERENCES financeiro.faturas(id);


--
-- Name: fk_rails_29a7c42f1c; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_movimentos
    ADD CONSTRAINT fk_rails_29a7c42f1c FOREIGN KEY (pessoa_id) REFERENCES financeiro.pessoas(id);


--
-- Name: fk_rails_2c0070d11e; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.tickets
    ADD CONSTRAINT fk_rails_2c0070d11e FOREIGN KEY (cliente_id) REFERENCES financeiro.clientes(id);


--
-- Name: fk_rails_36203af0ac; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.evento_contratos
    ADD CONSTRAINT fk_rails_36203af0ac FOREIGN KEY (pessoa_id) REFERENCES financeiro.pessoas(id);


--
-- Name: fk_rails_41b699d639; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.fatura_itens
    ADD CONSTRAINT fk_rails_41b699d639 FOREIGN KEY (pessoa_id) REFERENCES financeiro.pessoas(id);


--
-- Name: fk_rails_4b12b84b0d; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contratos
    ADD CONSTRAINT fk_rails_4b12b84b0d FOREIGN KEY (forma_pagamento_id) REFERENCES financeiro.forma_pagamentos(id);


--
-- Name: fk_rails_5720d03496; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.item_contratos
    ADD CONSTRAINT fk_rails_5720d03496 FOREIGN KEY (produto_id) REFERENCES financeiro.produtos(id);


--
-- Name: fk_rails_590c9073f0; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.produtos
    ADD CONSTRAINT fk_rails_590c9073f0 FOREIGN KEY (grupo_id) REFERENCES financeiro.grupos(id);


--
-- Name: fk_rails_6339760cdb; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.fatura_itens
    ADD CONSTRAINT fk_rails_6339760cdb FOREIGN KEY (produto_id) REFERENCES financeiro.produtos(id);


--
-- Name: fk_rails_7118cf7082; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.contratos
    ADD CONSTRAINT fk_rails_7118cf7082 FOREIGN KEY (cliente_id) REFERENCES financeiro.clientes(id);


--
-- Name: fk_rails_7819d066a4; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.clientes
    ADD CONSTRAINT fk_rails_7819d066a4 FOREIGN KEY (contador_id) REFERENCES financeiro.contadores(id);


--
-- Name: fk_rails_7b6aa07c78; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.clientes
    ADD CONSTRAINT fk_rails_7b6aa07c78 FOREIGN KEY (pessoa_id) REFERENCES financeiro.pessoas(id);


--
-- Name: fk_rails_81b663bea4; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.pessoas
    ADD CONSTRAINT fk_rails_81b663bea4 FOREIGN KEY (contador_id) REFERENCES financeiro.contadores(id);


--
-- Name: fk_rails_94e3092784; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.eventos
    ADD CONSTRAINT fk_rails_94e3092784 FOREIGN KEY (forma_pagamento_id) REFERENCES financeiro.forma_pagamentos(id);


--
-- Name: fk_rails_a36a1e5090; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.faturas
    ADD CONSTRAINT fk_rails_a36a1e5090 FOREIGN KEY (contrato_id) REFERENCES financeiro.contratos(id);


--
-- Name: fk_rails_dba027c891; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.ticket_movimentos
    ADD CONSTRAINT fk_rails_dba027c891 FOREIGN KEY (ticket_id) REFERENCES financeiro.tickets(id);


--
-- Name: fk_rails_f2b9d888e2; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.eventos
    ADD CONSTRAINT fk_rails_f2b9d888e2 FOREIGN KEY (pessoa_id) REFERENCES financeiro.pessoas(id);


--
-- Name: fk_rails_f49398363f; Type: FK CONSTRAINT; Schema: financeiro; Owner: faturamento
--

ALTER TABLE ONLY financeiro.evento_contratos
    ADD CONSTRAINT fk_rails_f49398363f FOREIGN KEY (contrato_id) REFERENCES financeiro.contratos(id);


--
-- Name: fk_rails_1345469dfd; Type: FK CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.eventos
    ADD CONSTRAINT fk_rails_1345469dfd FOREIGN KEY (fatura_id) REFERENCES kallario.faturas(id);


--
-- Name: fk_rails_a36a1e5090; Type: FK CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.faturas
    ADD CONSTRAINT fk_rails_a36a1e5090 FOREIGN KEY (contrato_id) REFERENCES kallario.contratos(id);


--
-- Name: fk_rails_c7d03eb372; Type: FK CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.contratos
    ADD CONSTRAINT fk_rails_c7d03eb372 FOREIGN KEY (pessoa_id) REFERENCES kallario.pessoas(id);


--
-- Name: fk_rails_f2b9d888e2; Type: FK CONSTRAINT; Schema: kallario; Owner: faturamento
--

ALTER TABLE ONLY kallario.eventos
    ADD CONSTRAINT fk_rails_f2b9d888e2 FOREIGN KEY (pessoa_id) REFERENCES kallario.pessoas(id);


--
-- Name: fk_rails_1345469dfd; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.eventos
    ADD CONSTRAINT fk_rails_1345469dfd FOREIGN KEY (fatura_id) REFERENCES minhascontas.faturas(id);


--
-- Name: fk_rails_14ff4bcf84; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.item_contratos
    ADD CONSTRAINT fk_rails_14ff4bcf84 FOREIGN KEY (contrato_id) REFERENCES minhascontas.contratos(id);


--
-- Name: fk_rails_20838c8bc1; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.fatura_itens
    ADD CONSTRAINT fk_rails_20838c8bc1 FOREIGN KEY (fatura_id) REFERENCES minhascontas.faturas(id);


--
-- Name: fk_rails_29a7c42f1c; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_movimentos
    ADD CONSTRAINT fk_rails_29a7c42f1c FOREIGN KEY (pessoa_id) REFERENCES minhascontas.pessoas(id);


--
-- Name: fk_rails_2c0070d11e; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.tickets
    ADD CONSTRAINT fk_rails_2c0070d11e FOREIGN KEY (cliente_id) REFERENCES minhascontas.clientes(id);


--
-- Name: fk_rails_36203af0ac; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.evento_contratos
    ADD CONSTRAINT fk_rails_36203af0ac FOREIGN KEY (pessoa_id) REFERENCES minhascontas.pessoas(id);


--
-- Name: fk_rails_41b699d639; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.fatura_itens
    ADD CONSTRAINT fk_rails_41b699d639 FOREIGN KEY (pessoa_id) REFERENCES minhascontas.pessoas(id);


--
-- Name: fk_rails_4b12b84b0d; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contratos
    ADD CONSTRAINT fk_rails_4b12b84b0d FOREIGN KEY (forma_pagamento_id) REFERENCES minhascontas.forma_pagamentos(id);


--
-- Name: fk_rails_5720d03496; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.item_contratos
    ADD CONSTRAINT fk_rails_5720d03496 FOREIGN KEY (produto_id) REFERENCES minhascontas.produtos(id);


--
-- Name: fk_rails_590c9073f0; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.produtos
    ADD CONSTRAINT fk_rails_590c9073f0 FOREIGN KEY (grupo_id) REFERENCES minhascontas.grupos(id);


--
-- Name: fk_rails_6339760cdb; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.fatura_itens
    ADD CONSTRAINT fk_rails_6339760cdb FOREIGN KEY (produto_id) REFERENCES minhascontas.produtos(id);


--
-- Name: fk_rails_7118cf7082; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.contratos
    ADD CONSTRAINT fk_rails_7118cf7082 FOREIGN KEY (cliente_id) REFERENCES minhascontas.clientes(id);


--
-- Name: fk_rails_7819d066a4; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.clientes
    ADD CONSTRAINT fk_rails_7819d066a4 FOREIGN KEY (contador_id) REFERENCES minhascontas.contadores(id);


--
-- Name: fk_rails_7b6aa07c78; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.clientes
    ADD CONSTRAINT fk_rails_7b6aa07c78 FOREIGN KEY (pessoa_id) REFERENCES minhascontas.pessoas(id);


--
-- Name: fk_rails_81b663bea4; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.pessoas
    ADD CONSTRAINT fk_rails_81b663bea4 FOREIGN KEY (contador_id) REFERENCES minhascontas.contadores(id);


--
-- Name: fk_rails_94e3092784; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.eventos
    ADD CONSTRAINT fk_rails_94e3092784 FOREIGN KEY (forma_pagamento_id) REFERENCES minhascontas.forma_pagamentos(id);


--
-- Name: fk_rails_a36a1e5090; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.faturas
    ADD CONSTRAINT fk_rails_a36a1e5090 FOREIGN KEY (contrato_id) REFERENCES minhascontas.contratos(id);


--
-- Name: fk_rails_dba027c891; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.ticket_movimentos
    ADD CONSTRAINT fk_rails_dba027c891 FOREIGN KEY (ticket_id) REFERENCES minhascontas.tickets(id);


--
-- Name: fk_rails_f2b9d888e2; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.eventos
    ADD CONSTRAINT fk_rails_f2b9d888e2 FOREIGN KEY (pessoa_id) REFERENCES minhascontas.pessoas(id);


--
-- Name: fk_rails_f49398363f; Type: FK CONSTRAINT; Schema: minhascontas; Owner: faturamento
--

ALTER TABLE ONLY minhascontas.evento_contratos
    ADD CONSTRAINT fk_rails_f49398363f FOREIGN KEY (contrato_id) REFERENCES minhascontas.contratos(id);


--
-- Name: fk_rails_1345469dfd; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT fk_rails_1345469dfd FOREIGN KEY (fatura_id) REFERENCES public.faturas(id);


--
-- Name: fk_rails_14ff4bcf84; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.item_contratos
    ADD CONSTRAINT fk_rails_14ff4bcf84 FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: fk_rails_20838c8bc1; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.fatura_itens
    ADD CONSTRAINT fk_rails_20838c8bc1 FOREIGN KEY (fatura_id) REFERENCES public.faturas(id);


--
-- Name: fk_rails_29a7c42f1c; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_movimentos
    ADD CONSTRAINT fk_rails_29a7c42f1c FOREIGN KEY (pessoa_id) REFERENCES public.pessoas(id);


--
-- Name: fk_rails_2c0070d11e; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_rails_2c0070d11e FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: fk_rails_36203af0ac; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.evento_contratos
    ADD CONSTRAINT fk_rails_36203af0ac FOREIGN KEY (pessoa_id) REFERENCES public.pessoas(id);


--
-- Name: fk_rails_41b699d639; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.fatura_itens
    ADD CONSTRAINT fk_rails_41b699d639 FOREIGN KEY (pessoa_id) REFERENCES public.pessoas(id);


--
-- Name: fk_rails_4b12b84b0d; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT fk_rails_4b12b84b0d FOREIGN KEY (forma_pagamento_id) REFERENCES public.forma_pagamentos(id);


--
-- Name: fk_rails_5720d03496; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.item_contratos
    ADD CONSTRAINT fk_rails_5720d03496 FOREIGN KEY (produto_id) REFERENCES public.produtos(id);


--
-- Name: fk_rails_590c9073f0; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT fk_rails_590c9073f0 FOREIGN KEY (grupo_id) REFERENCES public.grupos(id);


--
-- Name: fk_rails_6339760cdb; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.fatura_itens
    ADD CONSTRAINT fk_rails_6339760cdb FOREIGN KEY (produto_id) REFERENCES public.produtos(id);


--
-- Name: fk_rails_7118cf7082; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT fk_rails_7118cf7082 FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: fk_rails_7819d066a4; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT fk_rails_7819d066a4 FOREIGN KEY (contador_id) REFERENCES public.contadores(id);


--
-- Name: fk_rails_7b6aa07c78; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT fk_rails_7b6aa07c78 FOREIGN KEY (pessoa_id) REFERENCES public.pessoas(id);


--
-- Name: fk_rails_81b663bea4; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.pessoas
    ADD CONSTRAINT fk_rails_81b663bea4 FOREIGN KEY (contador_id) REFERENCES public.contadores(id);


--
-- Name: fk_rails_94e3092784; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT fk_rails_94e3092784 FOREIGN KEY (forma_pagamento_id) REFERENCES public.forma_pagamentos(id);


--
-- Name: fk_rails_a36a1e5090; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.faturas
    ADD CONSTRAINT fk_rails_a36a1e5090 FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: fk_rails_dba027c891; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.ticket_movimentos
    ADD CONSTRAINT fk_rails_dba027c891 FOREIGN KEY (ticket_id) REFERENCES public.tickets(id);


--
-- Name: fk_rails_f2b9d888e2; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT fk_rails_f2b9d888e2 FOREIGN KEY (pessoa_id) REFERENCES public.pessoas(id);


--
-- Name: fk_rails_f49398363f; Type: FK CONSTRAINT; Schema: public; Owner: faturamento
--

ALTER TABLE ONLY public.evento_contratos
    ADD CONSTRAINT fk_rails_f49398363f FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: SCHEMA financeiro; Type: ACL; Schema: -; Owner: faturamento
--

REVOKE ALL ON SCHEMA financeiro FROM PUBLIC;
REVOKE ALL ON SCHEMA financeiro FROM faturamento;
GRANT ALL ON SCHEMA financeiro TO faturamento;
GRANT USAGE ON SCHEMA financeiro TO lipinformatica;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT USAGE ON SCHEMA public TO lipinformatica;


--
-- Name: TABLE ajudas; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.ajudas FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.ajudas FROM faturamento;
GRANT ALL ON TABLE financeiro.ajudas TO faturamento;
GRANT SELECT ON TABLE financeiro.ajudas TO lipinformatica;


--
-- Name: SEQUENCE ajudas_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.ajudas_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.ajudas_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.ajudas_id_seq TO faturamento;


--
-- Name: TABLE ar_internal_metadata; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.ar_internal_metadata FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.ar_internal_metadata FROM faturamento;
GRANT ALL ON TABLE financeiro.ar_internal_metadata TO faturamento;
GRANT SELECT ON TABLE financeiro.ar_internal_metadata TO lipinformatica;


--
-- Name: TABLE chaves; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.chaves FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.chaves FROM faturamento;
GRANT ALL ON TABLE financeiro.chaves TO faturamento;
GRANT SELECT ON TABLE financeiro.chaves TO lipinformatica;


--
-- Name: SEQUENCE chaves_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.chaves_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.chaves_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.chaves_id_seq TO faturamento;


--
-- Name: TABLE clientes; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.clientes FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.clientes FROM faturamento;
GRANT ALL ON TABLE financeiro.clientes TO faturamento;
GRANT SELECT ON TABLE financeiro.clientes TO lipinformatica;


--
-- Name: SEQUENCE clientes_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.clientes_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.clientes_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.clientes_id_seq TO faturamento;


--
-- Name: TABLE contadores; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.contadores FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.contadores FROM faturamento;
GRANT ALL ON TABLE financeiro.contadores TO faturamento;
GRANT SELECT ON TABLE financeiro.contadores TO lipinformatica;


--
-- Name: SEQUENCE contadores_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.contadores_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.contadores_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.contadores_id_seq TO faturamento;


--
-- Name: TABLE contratos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.contratos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.contratos FROM faturamento;
GRANT ALL ON TABLE financeiro.contratos TO faturamento;
GRANT SELECT ON TABLE financeiro.contratos TO lipinformatica;


--
-- Name: SEQUENCE contratos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.contratos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.contratos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.contratos_id_seq TO faturamento;


--
-- Name: TABLE empresas; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.empresas FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.empresas FROM faturamento;
GRANT ALL ON TABLE financeiro.empresas TO faturamento;
GRANT SELECT ON TABLE financeiro.empresas TO lipinformatica;


--
-- Name: SEQUENCE empresas_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.empresas_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.empresas_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.empresas_id_seq TO faturamento;


--
-- Name: TABLE evento_contratos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.evento_contratos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.evento_contratos FROM faturamento;
GRANT ALL ON TABLE financeiro.evento_contratos TO faturamento;
GRANT SELECT ON TABLE financeiro.evento_contratos TO lipinformatica;


--
-- Name: SEQUENCE evento_contratos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.evento_contratos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.evento_contratos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.evento_contratos_id_seq TO faturamento;


--
-- Name: TABLE eventos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.eventos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.eventos FROM faturamento;
GRANT ALL ON TABLE financeiro.eventos TO faturamento;
GRANT SELECT ON TABLE financeiro.eventos TO lipinformatica;


--
-- Name: SEQUENCE eventos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.eventos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.eventos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.eventos_id_seq TO faturamento;


--
-- Name: TABLE fatura_itens; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.fatura_itens FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.fatura_itens FROM faturamento;
GRANT ALL ON TABLE financeiro.fatura_itens TO faturamento;
GRANT SELECT ON TABLE financeiro.fatura_itens TO lipinformatica;


--
-- Name: SEQUENCE fatura_itens_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.fatura_itens_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.fatura_itens_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.fatura_itens_id_seq TO faturamento;


--
-- Name: TABLE faturas; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.faturas FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.faturas FROM faturamento;
GRANT ALL ON TABLE financeiro.faturas TO faturamento;
GRANT SELECT ON TABLE financeiro.faturas TO lipinformatica;


--
-- Name: SEQUENCE faturas_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.faturas_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.faturas_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.faturas_id_seq TO faturamento;


--
-- Name: TABLE forma_pagamentos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.forma_pagamentos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.forma_pagamentos FROM faturamento;
GRANT ALL ON TABLE financeiro.forma_pagamentos TO faturamento;
GRANT SELECT ON TABLE financeiro.forma_pagamentos TO lipinformatica;


--
-- Name: SEQUENCE forma_pagamentos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.forma_pagamentos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.forma_pagamentos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.forma_pagamentos_id_seq TO faturamento;


--
-- Name: TABLE grupos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.grupos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.grupos FROM faturamento;
GRANT ALL ON TABLE financeiro.grupos TO faturamento;
GRANT SELECT ON TABLE financeiro.grupos TO lipinformatica;


--
-- Name: SEQUENCE grupos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.grupos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.grupos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.grupos_id_seq TO faturamento;


--
-- Name: TABLE item_contratos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.item_contratos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.item_contratos FROM faturamento;
GRANT ALL ON TABLE financeiro.item_contratos TO faturamento;
GRANT SELECT ON TABLE financeiro.item_contratos TO lipinformatica;


--
-- Name: SEQUENCE item_contratos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.item_contratos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.item_contratos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.item_contratos_id_seq TO faturamento;


--
-- Name: TABLE listagem_faturas; Type: ACL; Schema: financeiro; Owner: luiz
--

REVOKE ALL ON TABLE financeiro.listagem_faturas FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.listagem_faturas FROM luiz;
GRANT ALL ON TABLE financeiro.listagem_faturas TO luiz;
GRANT SELECT ON TABLE financeiro.listagem_faturas TO lipinformatica;
GRANT ALL ON TABLE financeiro.listagem_faturas TO faturamento;


--
-- Name: TABLE notificacoes; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.notificacoes FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.notificacoes FROM faturamento;
GRANT ALL ON TABLE financeiro.notificacoes TO faturamento;
GRANT SELECT ON TABLE financeiro.notificacoes TO lipinformatica;


--
-- Name: SEQUENCE notificacoes_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.notificacoes_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.notificacoes_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.notificacoes_id_seq TO faturamento;


--
-- Name: TABLE pessoas; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.pessoas FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.pessoas FROM faturamento;
GRANT ALL ON TABLE financeiro.pessoas TO faturamento;
GRANT SELECT ON TABLE financeiro.pessoas TO lipinformatica;


--
-- Name: SEQUENCE pessoas_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.pessoas_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.pessoas_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.pessoas_id_seq TO faturamento;


--
-- Name: TABLE produtos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.produtos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.produtos FROM faturamento;
GRANT ALL ON TABLE financeiro.produtos TO faturamento;
GRANT SELECT ON TABLE financeiro.produtos TO lipinformatica;


--
-- Name: SEQUENCE produtos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.produtos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.produtos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.produtos_id_seq TO faturamento;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.schema_migrations FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.schema_migrations FROM faturamento;
GRANT ALL ON TABLE financeiro.schema_migrations TO faturamento;
GRANT SELECT ON TABLE financeiro.schema_migrations TO lipinformatica;


--
-- Name: TABLE ticket_configs; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.ticket_configs FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.ticket_configs FROM faturamento;
GRANT ALL ON TABLE financeiro.ticket_configs TO faturamento;
GRANT SELECT ON TABLE financeiro.ticket_configs TO lipinformatica;


--
-- Name: SEQUENCE ticket_configs_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.ticket_configs_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.ticket_configs_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.ticket_configs_id_seq TO faturamento;


--
-- Name: TABLE ticket_movimentos; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.ticket_movimentos FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.ticket_movimentos FROM faturamento;
GRANT ALL ON TABLE financeiro.ticket_movimentos TO faturamento;
GRANT SELECT ON TABLE financeiro.ticket_movimentos TO lipinformatica;


--
-- Name: SEQUENCE ticket_movimentos_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.ticket_movimentos_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.ticket_movimentos_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.ticket_movimentos_id_seq TO faturamento;


--
-- Name: TABLE tickets; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON TABLE financeiro.tickets FROM PUBLIC;
REVOKE ALL ON TABLE financeiro.tickets FROM faturamento;
GRANT ALL ON TABLE financeiro.tickets TO faturamento;
GRANT SELECT ON TABLE financeiro.tickets TO lipinformatica;


--
-- Name: SEQUENCE tickets_id_seq; Type: ACL; Schema: financeiro; Owner: faturamento
--

REVOKE ALL ON SEQUENCE financeiro.tickets_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE financeiro.tickets_id_seq FROM faturamento;
GRANT ALL ON SEQUENCE financeiro.tickets_id_seq TO faturamento;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: financeiro; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA financeiro REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA financeiro REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA financeiro GRANT SELECT ON TABLES  TO lipinformatica;


--
-- PostgreSQL database dump complete
--

